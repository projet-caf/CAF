-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le: Lun 17 Septembre 2012 à 16:37
-- Version du serveur: 5.5.27-1~dotdeb.0
-- Version de PHP: 5.3.16-1~dotdeb.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `cafinancement`
--

-- --------------------------------------------------------

--
-- Structure de la table `agence`
--

CREATE TABLE IF NOT EXISTS `agence` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `published` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Contenu de la table `agence`
--

INSERT INTO `agence` (`id`, `name`, `published`) VALUES
(1, 'Agence Annecy', 0),
(2, 'Agence 2', 1),
(3, 'agence 3', 1);

-- --------------------------------------------------------

--
-- Structure de la table `agencecaisseregionale`
--

CREATE TABLE IF NOT EXISTS `agencecaisseregionale` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `published` tinyint(1) NOT NULL,
  `ville` varchar(255) NOT NULL,
  `numero` varchar(255) NOT NULL,
  `caisseRegional_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_29B7C9F5882C8A0F` (`caisseRegional_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Contenu de la table `agencecaisseregionale`
--

INSERT INTO `agencecaisseregionale` (`id`, `published`, `ville`, `numero`, `caisseRegional_id`) VALUES
(1, 1, 'Annecy', '235', 1),
(2, 1, 'Geneve', '625', 2),
(3, 1, 'Milan', '569', 1),
(4, 1, 'Paris', '198', 2),
(5, 1, 'Grenoble', '898', 1),
(6, 1, 'Chambery', '363', 4);

-- --------------------------------------------------------

--
-- Structure de la table `banner`
--

CREATE TABLE IF NOT EXISTS `banner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `campaign_name` varchar(255) NOT NULL,
  `alias_campaign_name` varchar(255) NOT NULL,
  `published` tinyint(1) NOT NULL,
  `banner_name` varchar(255) NOT NULL,
  `alias_banner_name` varchar(255) NOT NULL,
  `file` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Contenu de la table `banner`
--

INSERT INTO `banner` (`id`, `campaign_name`, `alias_campaign_name`, `published`, `banner_name`, `alias_banner_name`, `file`, `link`, `path`) VALUES
(1, 'nomCampagne', 'nomcampagne', 1, 'nomBannierekk', 'nombanniere', 'bannieredroite.jpg', 'http://symfony.com/doc/current/book/forms.html', '/media/bannieres'),
(2, 'nom campagne 1', 'nom-campagne-1', 1, 'nom banniere 1', 'nom-banniere-1', 'bannieredroite1.jpg', 'http://twitter.github.com/bootstrap/base-css.html#typography', '/media/bannieres'),
(3, 'nom campagne 2', 'nom-campagne-2', 1, 'nom banniere 2', 'nom-banniere-2', 'bannieredroite2.jpg', 'http://twitter.github.com/bootstrap/base-css.html#typography', '/media/bannieres');

-- --------------------------------------------------------

--
-- Structure de la table `bloc`
--

CREATE TABLE IF NOT EXISTS `bloc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `params` varchar(255) DEFAULT NULL,
  `published` tinyint(1) NOT NULL,
  `ordre_bloc` varchar(255) DEFAULT NULL,
  `all_published` tinyint(1) DEFAULT NULL,
  `display_title` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Contenu de la table `bloc`
--

INSERT INTO `bloc` (`id`, `title`, `position`, `type`, `params`, `published`, `ordre_bloc`, `all_published`, `display_title`) VALUES
(1, 'Main menu', 'top', 'BlocMenu', '{"bloc_type":"BlocMenu","bloc_id":1}', 1, '1', 1, 0),
(2, 'Actualités', 'right', 'BlocActu', '{"bloc_type":"BlocActu","bloc_id":1}', 1, '1', 0, 0),
(3, 'Documents', 'right', 'BlocActu', '{"bloc_type":"BlocActu","bloc_id":2}', 1, '2', 0, 0),
(4, 'Qui sommes-nous ?', 'left', 'BlocMenuLeft', '{"bloc_type":"BlocMenuLeft","bloc_id":1}', 1, '1', 0, 0),
(5, 'Coordonnées', 'left', 'BlocHtml', '{"bloc_type":"BlocHtml","bloc_id":1}', 1, '2', 0, 0),
(6, 'Cours de change', 'left', 'BlocHtml', '{"bloc_type":"BlocHtml","bloc_id":2}', 1, '3', 0, 0),
(8, 'Slider Accueil h', 'banner_top', 'BlocBannerSlide', '{"bloc_type":"BlocBannerSlide","bloc_id":1}', 1, '1', 0, 0),
(9, 'Test ma banniere droite', 'right', 'BlocBannerRight', '{"bloc_type":"BlocBannerRight","bloc_id":1}', 1, '3', 0, 0),
(10, 'Bateau', 'banner_top', 'BlocBanner', '{"bloc_type":"BlocBanner","bloc_id":1}', 1, '2', 1, 0),
(11, 'menu banniere', 'banner', 'BlocMenu', '{"bloc_type":"BlocMenu","bloc_id":2}', 1, '1', 1, 0),
(12, 'Menu footer', 'bottom', 'BlocMenu', '{"bloc_type":"BlocMenu","bloc_id":3}', 1, '1', 1, 0);

-- --------------------------------------------------------

--
-- Structure de la table `blocactu`
--

CREATE TABLE IF NOT EXISTS `blocactu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bloc_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `limit_value` int(11) NOT NULL,
  `display_type` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_67B9FF1A12469DE2` (`category_id`),
  KEY `IDX_67B9FF1A5582E9C0` (`bloc_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `blocactu`
--

INSERT INTO `blocactu` (`id`, `bloc_id`, `category_id`, `limit_value`, `display_type`) VALUES
(1, 2, 1, 3, 'actu'),
(2, 3, 4, 3, 'document');

-- --------------------------------------------------------

--
-- Structure de la table `blocbanner`
--

CREATE TABLE IF NOT EXISTS `blocbanner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bloc_id` int(11) DEFAULT NULL,
  `image` longtext COMMENT '(DC2Type:array)',
  `path` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_E10533A05582E9C0` (`bloc_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `blocbanner`
--

INSERT INTO `blocbanner` (`id`, `bloc_id`, `image`, `path`) VALUES
(1, 10, 'a:3:{s:5:"image";s:47:"uploads/banners_bloc/banners/504db8ac15025.jpeg";s:3:"alt";N;s:5:"title";N;}', 'uploads/banners_bloc/banners/504db8ac15025.jpeg');

-- --------------------------------------------------------

--
-- Structure de la table `blocbannerright`
--

CREATE TABLE IF NOT EXISTS `blocbannerright` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bloc_id` int(11) DEFAULT NULL,
  `date_debut` date NOT NULL,
  `date_fin` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_67DDBD8B5582E9C0` (`bloc_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `blocbannerright`
--

INSERT INTO `blocbannerright` (`id`, `bloc_id`, `date_debut`, `date_fin`) VALUES
(1, 9, '2012-09-07', '2012-09-15');

-- --------------------------------------------------------

--
-- Structure de la table `blocbannerright_banner`
--

CREATE TABLE IF NOT EXISTS `blocbannerright_banner` (
  `blocbannerright_id` int(11) NOT NULL,
  `banner_id` int(11) NOT NULL,
  PRIMARY KEY (`blocbannerright_id`,`banner_id`),
  KEY `IDX_6D7F959522284FAA` (`blocbannerright_id`),
  KEY `IDX_6D7F9595684EC833` (`banner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `blocbannerright_banner`
--

INSERT INTO `blocbannerright_banner` (`blocbannerright_id`, `banner_id`) VALUES
(1, 1),
(1, 2),
(1, 3);

-- --------------------------------------------------------

--
-- Structure de la table `blocbannerslide`
--

CREATE TABLE IF NOT EXISTS `blocbannerslide` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bloc_id` int(11) DEFAULT NULL,
  `images` longtext COMMENT '(DC2Type:array)',
  `path` text COMMENT '(DC2Type:array)',
  `url` varchar(255) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_A1F826FD5582E9C0` (`bloc_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `blocbannerslide`
--

INSERT INTO `blocbannerslide` (`id`, `bloc_id`, `images`, `path`, `url`, `size`) VALUES
(1, 8, 'a:3:{i:0;a:3:{s:5:"image";a:3:{s:5:"image";s:62:"medias/banners/uploads/banners_bloc/banners/5046eee4a8d64.jpeg";s:3:"alt";N;s:5:"title";N;}s:10:"first_line";s:17:"Mon Premier texte";s:11:"second_line";s:18:"Mon deuxieme Texte";}i:1;a:3:{s:5:"image";a:3:{s:5:"image";s:62:"medias/banners/uploads/banners_bloc/banners/50474c728572d.jpeg";s:3:"alt";N;s:5:"title";N;}s:10:"first_line";s:19:"Mon Premier texte 1";s:11:"second_line";s:20:"Mon deuxieme Texte 1";}i:2;a:3:{s:5:"image";a:3:{s:5:"image";s:62:"medias/banners/uploads/banners_bloc/banners/504db98e97090.jpeg";s:3:"alt";N;s:5:"title";N;}s:10:"first_line";s:19:"Mon premier texte 2";s:11:"second_line";s:20:"Mon deuxieme texte 2";}}', 's:228:"a:3:{i:0;s:62:"medias/banners/uploads/banners_bloc/banners/5046eee4a8d64.jpeg";i:1;s:62:"medias/banners/uploads/banners_bloc/banners/50474c728572d.jpeg";i:2;s:62:"medias/banners/uploads/banners_bloc/banners/504db98e97090.jpeg";}";', NULL, 3);

-- --------------------------------------------------------

--
-- Structure de la table `blochtml`
--

CREATE TABLE IF NOT EXISTS `blochtml` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bloc_id` int(11) DEFAULT NULL,
  `content` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_FCB304BD5582E9C0` (`bloc_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Contenu de la table `blochtml`
--

INSERT INTO `blochtml` (`id`, `bloc_id`, `content`) VALUES
(1, 5, '<ul class="unstyled">\r\n	<li>\r\n		Cr&eacute;dit Agricole Financements (Suisse) Sa</li>\r\n	<li>\r\n		67 rue du Rh&ocirc;ne - CP 6265</li>\r\n	<li>\r\n		1207 Gen&egrave;ve</li>\r\n</ul>\r\n<p>\r\n	&nbsp;</p>\r\n<ul class="unstyled">\r\n	<li>\r\n		BIC/SWIFT.....BCGECHGGXXX</li>\r\n	<li>\r\n		Clearing/CB.......................788</li>\r\n	<li>\r\n		CCP CHF......................12-1-2</li>\r\n	<li>\r\n		CCP EUR ............91-518772-8</li>\r\n	<li>\r\n		TVA ...........................143.948</li>\r\n</ul>\r\n<p>\r\n	&nbsp;</p>'),
(2, 6, '<ul class="unstyled">\r\n	<li>\r\n		<img src="/web/bundles/caffront/images/europe.png" /><em>Euro</em>.........1.2318</li>\r\n	<li>\r\n		<img src="/web/bundles/caffront/images/usa.png" /><em>USD</em>.........0.9968</li>\r\n	<li>\r\n		<img src="/web/bundles/caffront/images/uk.png" /><em>GBP</em>.........1.5432</li>\r\n</ul>');

-- --------------------------------------------------------

--
-- Structure de la table `blocmenu`
--

CREATE TABLE IF NOT EXISTS `blocmenu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bloc_id` int(11) DEFAULT NULL,
  `menu_id` int(11) DEFAULT NULL,
  `display_type` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_99CFC6CBCCD7E912` (`menu_id`),
  KEY `IDX_99CFC6CB5582E9C0` (`bloc_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Contenu de la table `blocmenu`
--

INSERT INTO `blocmenu` (`id`, `bloc_id`, `menu_id`, `display_type`) VALUES
(1, 1, 2, 'header'),
(2, 11, 3, 'banner'),
(3, 12, 4, 'footer');

-- --------------------------------------------------------

--
-- Structure de la table `blocmenuleft`
--

CREATE TABLE IF NOT EXISTS `blocmenuleft` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bloc_id` int(11) DEFAULT NULL,
  `menu_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_2B8A2BC2CCD7E912` (`menu_id`),
  KEY `IDX_2B8A2BC25582E9C0` (`bloc_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `blocmenuleft`
--

INSERT INTO `blocmenuleft` (`id`, `bloc_id`, `menu_id`) VALUES
(1, 4, 26);

-- --------------------------------------------------------

--
-- Structure de la table `bloc_category_de`
--

CREATE TABLE IF NOT EXISTS `bloc_category_de` (
  `bloc_id` int(11) NOT NULL,
  `categorytranslation_id` int(11) NOT NULL,
  PRIMARY KEY (`bloc_id`,`categorytranslation_id`),
  KEY `IDX_C96625515582E9C0` (`bloc_id`),
  KEY `IDX_C96625512D214E40` (`categorytranslation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `bloc_category_de`
--

INSERT INTO `bloc_category_de` (`bloc_id`, `categorytranslation_id`) VALUES
(2, 21),
(2, 24),
(3, 15),
(4, 15),
(5, 21),
(5, 24),
(6, 21),
(6, 24),
(8, 21);

-- --------------------------------------------------------

--
-- Structure de la table `bloc_category_en`
--

CREATE TABLE IF NOT EXISTS `bloc_category_en` (
  `bloc_id` int(11) NOT NULL,
  `categorytranslation_id` int(11) NOT NULL,
  PRIMARY KEY (`bloc_id`,`categorytranslation_id`),
  KEY `IDX_47AFCD985582E9C0` (`bloc_id`),
  KEY `IDX_47AFCD982D214E40` (`categorytranslation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `bloc_category_en`
--

INSERT INTO `bloc_category_en` (`bloc_id`, `categorytranslation_id`) VALUES
(2, 20),
(2, 23),
(3, 14),
(4, 2),
(4, 14),
(5, 20),
(5, 23),
(6, 20),
(6, 23),
(8, 23);

-- --------------------------------------------------------

--
-- Structure de la table `bloc_category_fr`
--

CREATE TABLE IF NOT EXISTS `bloc_category_fr` (
  `bloc_id` int(11) NOT NULL,
  `categorytranslation_id` int(11) NOT NULL,
  PRIMARY KEY (`bloc_id`,`categorytranslation_id`),
  KEY `IDX_7883C2145582E9C0` (`bloc_id`),
  KEY `IDX_7883C2142D214E40` (`categorytranslation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `bloc_category_fr`
--

INSERT INTO `bloc_category_fr` (`bloc_id`, `categorytranslation_id`) VALUES
(2, 19),
(2, 22),
(2, 25),
(3, 13),
(4, 1),
(4, 13),
(5, 19),
(5, 22),
(6, 19),
(6, 22),
(8, 22);

-- --------------------------------------------------------

--
-- Structure de la table `bloc_content_de`
--

CREATE TABLE IF NOT EXISTS `bloc_content_de` (
  `bloc_id` int(11) NOT NULL,
  `contenttranslation_id` int(11) NOT NULL,
  PRIMARY KEY (`bloc_id`,`contenttranslation_id`),
  KEY `IDX_A3C9F4A05582E9C0` (`bloc_id`),
  KEY `IDX_A3C9F4A068204D1A` (`contenttranslation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `bloc_content_de`
--

INSERT INTO `bloc_content_de` (`bloc_id`, `contenttranslation_id`) VALUES
(2, 57),
(8, 39);

-- --------------------------------------------------------

--
-- Structure de la table `bloc_content_en`
--

CREATE TABLE IF NOT EXISTS `bloc_content_en` (
  `bloc_id` int(11) NOT NULL,
  `contenttranslation_id` int(11) NOT NULL,
  PRIMARY KEY (`bloc_id`,`contenttranslation_id`),
  KEY `IDX_2D001C695582E9C0` (`bloc_id`),
  KEY `IDX_2D001C6968204D1A` (`contenttranslation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `bloc_content_en`
--

INSERT INTO `bloc_content_en` (`bloc_id`, `contenttranslation_id`) VALUES
(2, 56),
(4, 56),
(8, 38);

-- --------------------------------------------------------

--
-- Structure de la table `bloc_content_fr`
--

CREATE TABLE IF NOT EXISTS `bloc_content_fr` (
  `bloc_id` int(11) NOT NULL,
  `contenttranslation_id` int(11) NOT NULL,
  PRIMARY KEY (`bloc_id`,`contenttranslation_id`),
  KEY `IDX_122C13E55582E9C0` (`bloc_id`),
  KEY `IDX_122C13E568204D1A` (`contenttranslation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `bloc_content_fr`
--

INSERT INTO `bloc_content_fr` (`bloc_id`, `contenttranslation_id`) VALUES
(2, 55),
(4, 55),
(8, 37);

-- --------------------------------------------------------

--
-- Structure de la table `caisseregionale`
--

CREATE TABLE IF NOT EXISTS `caisseregionale` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `published` tinyint(1) NOT NULL,
  `label` varchar(255) NOT NULL,
  `numero` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Contenu de la table `caisseregionale`
--

INSERT INTO `caisseregionale` (`id`, `published`, `label`, `numero`) VALUES
(1, 1, 'CADS', 325),
(2, 1, 'SPVE', 532),
(3, 1, 'PACE', 236),
(4, 1, 'ABCH', 567),
(5, 1, 'ODIC', 759);

-- --------------------------------------------------------

--
-- Structure de la table `categories_ext`
--

CREATE TABLE IF NOT EXISTS `categories_ext` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `ordre` int(11) DEFAULT NULL,
  `lft` int(11) NOT NULL,
  `lvl` int(11) NOT NULL,
  `rgt` int(11) NOT NULL,
  `root` int(11) DEFAULT NULL,
  `template` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_3FA0CAAA727ACA70` (`parent_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- Contenu de la table `categories_ext`
--

INSERT INTO `categories_ext` (`id`, `parent_id`, `ordre`, `lft`, `lvl`, `rgt`, `root`, `template`) VALUES
(1, NULL, NULL, 1, 0, 4, 1, 'actualites'),
(4, NULL, NULL, 1, 0, 2, 4, 'document'),
(7, NULL, NULL, 1, 0, 2, 7, 'agence'),
(8, 1, NULL, 2, 1, 3, 1, 'actualites'),
(9, NULL, NULL, 1, 0, 2, 9, 'default'),
(10, NULL, NULL, 1, 0, 6, 10, 'accueil'),
(11, 10, 0, 2, 1, 3, 10, 'default');

-- --------------------------------------------------------

--
-- Structure de la table `category_country`
--

CREATE TABLE IF NOT EXISTS `category_country` (
  `categorytranslation_id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  PRIMARY KEY (`categorytranslation_id`,`country_id`),
  KEY `IDX_94AB89182D214E40` (`categorytranslation_id`),
  KEY `IDX_94AB8918F92F3E70` (`country_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `category_translation`
--

CREATE TABLE IF NOT EXISTS `category_translation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lang` int(11) DEFAULT NULL,
  `item_id` int(11) DEFAULT NULL,
  `published` tinyint(1) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `description` longtext,
  `url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_3F2070431098462` (`lang`),
  KEY `IDX_3F20704126F525E` (`item_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=37 ;

--
-- Contenu de la table `category_translation`
--

INSERT INTO `category_translation` (`id`, `lang`, `item_id`, `published`, `title`, `alias`, `description`, `url`) VALUES
(1, 1, 1, 1, 'Actualités', 'actualites-2', '', 'actualites.html'),
(2, 2, 1, 1, 'News', 'news', '', 'news.html'),
(3, 3, 1, 1, 'Nueue', 'nueue', '', 'nueue.html'),
(10, 1, 4, 1, 'Documentation', 'documentation', '', 'documentation.html'),
(11, 2, 4, 1, 'Documents', 'documents-1', '', 'documents-1.html'),
(12, 3, 4, 1, 'Docs', 'docs', '', 'docs.html'),
(13, 1, 7, 1, 'Agence', 'agence', '', 'agence.html'),
(14, 2, 7, 1, 'Agency', 'agency', '', 'agency.html'),
(15, 3, 7, 1, 'Agentur', 'agentur', '', 'agentur.html'),
(16, 1, 8, 1, 'Actualités 2012', 'actualites-2012', '<p>\r\n	Retrouvez toutes les actualit&eacute;s de l&#39;ann&eacute;e 2012 en un seul clic</p>', 'actualites-2012.html'),
(17, 2, 8, 1, 'News-2012', 'news-2012', '', 'news-2012.html'),
(18, 3, 8, 1, 'Nueue 2012', 'nueue-2012', '', 'nueue-2012.html'),
(19, 1, 9, 1, 'Générale', 'generale', '', 'generale.html'),
(20, 2, 9, 1, 'General', 'general', '', 'general.html'),
(21, 3, 9, 1, 'General', 'general-1', '', 'general-1.html'),
(22, 1, 10, 1, 'Accueil', 'accueil', '<p>\r\n	Lorem ipsum dolor sit amet, consetetur sadipscing elitr, At accusam aliquyam diam diam dolore dolores duo eirmod eos erat, et nonumy sed tempor et et invidunt justo labore Stet clita ea et gubergren, kasd magna no rebum.</p>\r\n<p>\r\n	Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi.</p>\r\n<p>\r\n	Consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Excepteur sint obcaecat cupiditat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.</p>\r\n<p>\r\n	Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.</p>\r\n<p>\r\n	Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi.</p>\r\n<p>\r\n	Consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Sanctus sea sed takimata ut vero voluptua.</p>\r\n', 'accueil.html'),
(23, 2, 10, 1, 'Home', 'home', '<p>\r\n	Lorem ipsum dolor sit amet, consetetur sadipscing elitr, At accusam aliquyam diam diam dolore dolores duo eirmod eos erat, et nonumy sed tempor et et invidunt justo labore Stet clita ea et gubergren, kasd magna no rebum.</p>\r\n<p>\r\n	Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi.</p>\r\n<p>\r\n	Consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Excepteur sint obcaecat cupiditat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.</p>\r\n<p>\r\n	Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.</p>\r\n<p>\r\n	Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi.</p>\r\n<p>\r\n	Consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Sanctus sea sed takimata ut vero voluptua.</p>\r\n', 'home.html'),
(24, 3, 10, 1, 'Startseite', 'startseite', '<p>\r\n	Lorem ipsum dolor sit amet, consetetur sadipscing elitr, At accusam aliquyam diam diam dolore dolores duo eirmod eos erat, et nonumy sed tempor et et invidunt justo labore Stet clita ea et gubergren, kasd magna no rebum.</p>\r\n<p>\r\n	Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi.</p>\r\n<p>\r\n	Consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Excepteur sint obcaecat cupiditat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.</p>\r\n<p>\r\n	Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.</p>\r\n<p>\r\n	Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi.</p>\r\n<p>\r\n	Consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Sanctus sea sed takimata ut vero voluptua.</p>\r\n', 'startseite.html'),
(25, 1, 11, 1, 'Qui sommes-nous?', 'qui-sommes-nous', '<p>\r\n	Qui-sommes-nous? la rubrique et la description de Cr&eacute;dit agricoles financements</p>\r\n', 'qui-sommes-nous.html'),
(26, 2, 11, 0, 'Who is', 'who-is', '', 'who-is.html'),
(27, 3, 11, 0, 'Uber uns', 'uber-uns', '', 'uber-uns.html');

-- --------------------------------------------------------

--
-- Structure de la table `conseiller`
--

CREATE TABLE IF NOT EXISTS `conseiller` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `agence_id` int(11) NOT NULL,
  `published` tinyint(1) NOT NULL,
  `name` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `numtel` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_18C69F97D725330D` (`agence_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `conseiller`
--

INSERT INTO `conseiller` (`id`, `agence_id`, `published`, `name`, `prenom`, `email`, `numtel`) VALUES
(1, 2, 0, 'Humex', 'Marie', 'marie.humex@ca.ch', '0476955976');

-- --------------------------------------------------------

--
-- Structure de la table `content`
--

CREATE TABLE IF NOT EXISTS `content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_content_taxonomy` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_FEC530A94C2F0703` (`id_content_taxonomy`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=23 ;

--
-- Contenu de la table `content`
--

INSERT INTO `content` (`id`, `id_content_taxonomy`) VALUES
(14, 1),
(16, 1),
(22, 1),
(18, 2),
(20, 2),
(12, 3),
(13, 3),
(15, 4),
(19, 4),
(21, 4);

-- --------------------------------------------------------

--
-- Structure de la table `contenttaxonomy`
--

CREATE TABLE IF NOT EXISTS `contenttaxonomy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(255) NOT NULL,
  `published` tinyint(1) NOT NULL,
  `template` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Contenu de la table `contenttaxonomy`
--

INSERT INTO `contenttaxonomy` (`id`, `libelle`, `published`, `template`) VALUES
(1, 'Actualités', 1, 'actualites'),
(2, 'Agence', 1, 'agence'),
(3, 'Document', 1, 'document'),
(4, 'Page', 1, 'default'),
(5, 'Accueil', 1, 'accueil');

-- --------------------------------------------------------

--
-- Structure de la table `contenttranslation`
--

CREATE TABLE IF NOT EXISTS `contenttranslation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lang` int(11) DEFAULT NULL,
  `item_id` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `alias` varchar(255) NOT NULL,
  `published` tinyint(1) NOT NULL,
  `urls` longtext NOT NULL COMMENT '(DC2Type:array)',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_4E1B03E531098462` (`lang`),
  KEY `IDX_4E1B03E5126F525E` (`item_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=61 ;

--
-- Contenu de la table `contenttranslation`
--

INSERT INTO `contenttranslation` (`id`, `lang`, `item_id`, `title`, `alias`, `published`, `urls`, `created`, `updated`) VALUES
(28, 1, 12, 'Guide des tarifs 2012', 'guide-des-tarifs-2012', 1, 'a:2:{i:0;s:38:"ch/documentation/guide-des-tarifs-2012";i:1;s:38:"fr/documentation/guide-des-tarifs-2012";}', '2012-08-23 21:27:59', '2012-09-12 10:35:58'),
(29, 2, 12, 'Prices guide 2012', 'prices-guide-2012', 1, 'a:2:{i:0;s:32:"ch/documents-1/prices-guide-2012";i:1;s:32:"fr/documents-1/prices-guide-2012";}', '2012-08-23 21:27:59', '2012-09-12 10:35:58'),
(30, 3, 12, 'Prices', 'prices', 1, 'a:2:{i:0;s:14:"ch/docs/prices";i:1;s:14:"fr/docs/prices";}', '2012-08-23 21:27:59', '2012-09-12 10:35:58'),
(31, 1, 13, 'Guide des offres', 'guide-des-offres', 1, 'a:2:{i:0;s:33:"ch/documentation/guide-des-offres";i:1;s:33:"fr/documentation/guide-des-offres";}', '2012-08-23 22:37:47', '2012-09-12 10:55:35'),
(32, 2, 13, 'Offers'' guide', 'offers-guide', 1, 'a:2:{i:0;s:27:"ch/documents-1/offers-guide";i:1;s:27:"fr/documents-1/offers-guide";}', '2012-08-23 22:37:47', '2012-09-12 10:55:35'),
(33, 3, 13, 'Offers'' guide', 'offers-guide-1', 1, 'a:2:{i:0;s:20:"ch/docs/offers-guide";i:1;s:20:"fr/docs/offers-guide";}', '2012-08-23 22:37:47', '2012-09-12 10:55:35'),
(34, 1, 14, 'Nouvelle plateforme e-banking', 'nouvelle-plateforme-e-banking', 1, 'a:4:{i:0;s:45:"ch/actualites-2/nouvelle-plateforme-e-banking";i:1;s:48:"ch/actualites-2012/nouvelle-plateforme-e-banking";i:2;s:45:"fr/actualites-2/nouvelle-plateforme-e-banking";i:3;s:48:"fr/actualites-2012/nouvelle-plateforme-e-banking";}', '2012-08-24 08:48:34', '2012-09-16 18:04:37'),
(35, 2, 14, 'Nouvelle plateforme e-banking', 'nouvelle-plateforme-e-banking-1', 1, 'a:2:{i:0;s:37:"ch/news/nouvelle-plateforme-e-banking";i:1;s:37:"fr/news/nouvelle-plateforme-e-banking";}', '2012-08-24 08:48:34', '2012-09-16 18:04:37'),
(36, 3, 14, 'Nouvelle plateforme e-banking', 'nouvelle-plateforme-e-banking-2', 1, 'a:2:{i:0;s:38:"ch/nueue/nouvelle-plateforme-e-banking";i:1;s:38:"fr/nueue/nouvelle-plateforme-e-banking";}', '2012-08-24 08:48:34', '2012-09-16 18:04:37'),
(37, 1, 15, 'Texte Accueil', 'texte-accueil', 1, 'a:2:{i:0;s:25:"ch/generale/texte-accueil";i:1;s:25:"fr/generale/texte-accueil";}', '2012-08-24 10:06:17', '2012-09-16 10:49:56'),
(38, 2, 15, 'Home', 'home', 1, 'a:2:{i:0;s:15:"ch/general/home";i:1;s:15:"fr/general/home";}', '2012-08-24 10:06:17', '2012-09-16 10:49:56'),
(39, 3, 15, 'Home', 'home-1', 1, 'a:2:{i:0;s:17:"ch/general-1/home";i:1;s:17:"fr/general-1/home";}', '2012-08-24 10:06:17', '2012-09-16 10:49:56'),
(40, 1, 16, 'Offre exceptionnelle 3', 'offre-exceptionnelle-2', 1, 'a:4:{i:0;s:38:"ch/actualites-2/offre-exceptionnelle-3";i:1;s:41:"ch/actualites-2012/offre-exceptionnelle-3";i:2;s:38:"fr/actualites-2/offre-exceptionnelle-3";i:3;s:41:"fr/actualites-2012/offre-exceptionnelle-3";}', '2012-08-24 14:08:54', '2012-09-16 17:47:41'),
(41, 2, 16, 'test 5', 'test-2', 1, 'a:2:{i:0;s:14:"ch/news/test-5";i:1;s:14:"fr/news/test-5";}', '2012-08-24 14:08:54', '2012-09-16 17:47:41'),
(42, 3, 16, 'teq', 'teq', 1, 'a:2:{i:0;s:12:"ch/nueue/teq";i:1;s:12:"fr/nueue/teq";}', '2012-08-24 14:08:54', '2012-09-16 17:47:41'),
(46, 1, 18, 'Test agence fr', 'test-agence-fr', 1, 'a:2:{i:0;s:24:"ch/agence/test-agence-fr";i:1;s:24:"fr/agence/test-agence-fr";}', '2012-09-10 15:45:14', '2012-09-14 17:07:00'),
(47, 2, 18, 'Test agency', 'test-agency', 1, 'a:2:{i:0;s:21:"ch/agency/test-agency";i:1;s:21:"fr/agency/test-agency";}', '2012-09-10 15:45:14', '2012-09-14 17:07:00'),
(48, 3, 18, 'Test agentur', 'test-agentur', 1, 'a:2:{i:0;s:23:"ch/agentur/test-agentur";i:1;s:23:"fr/agentur/test-agentur";}', '2012-09-10 15:45:14', '2012-09-14 17:07:00'),
(49, 1, 19, 'Chiffres clés', 'chiffres-cles', 1, 'a:2:{i:0;s:25:"ch/generale/chiffres-cles";i:1;s:25:"fr/generale/chiffres-cles";}', '2012-09-12 09:22:16', '2012-09-14 09:55:11'),
(50, 2, 19, 'Key figures', 'key-figures', 1, 'a:2:{i:0;s:22:"ch/general/key-figures";i:1;s:22:"fr/general/key-figures";}', '2012-09-12 09:22:16', '2012-09-14 09:55:11'),
(51, 3, 19, 'Key figures', 'key-figures-1', 1, 'a:2:{i:0;s:24:"ch/general-1/key-figures";i:1;s:24:"fr/general-1/key-figures";}', '2012-09-12 09:22:16', '2012-09-14 09:55:11'),
(52, 1, 20, 'Agence Genève Cornavin', 'agence-geneve-cornavin', 1, 'a:2:{i:0;s:32:"ch/agence/agence-geneve-cornavin";i:1;s:32:"fr/agence/agence-geneve-cornavin";}', '2012-09-13 09:08:16', '2012-09-17 08:49:08'),
(53, 2, 20, 'Agency Geneva Cornavin', 'agency-geneva-cornavin', 1, 'a:2:{i:0;s:32:"ch/agency/agency-geneva-cornavin";i:1;s:32:"fr/agency/agency-geneva-cornavin";}', '2012-09-13 09:08:16', '2012-09-17 08:49:08'),
(54, 3, 20, 'Genf Cornavin', 'genf-cornavin', 1, 'a:2:{i:0;s:24:"ch/agentur/genf-cornavin";i:1;s:24:"fr/agentur/genf-cornavin";}', '2012-09-13 09:08:16', '2012-09-17 08:49:08'),
(55, 1, 21, 'Historique', 'historique', 1, 'a:2:{i:0;s:29:"ch/qui-sommes-nous/historique";i:1;s:29:"fr/qui-sommes-nous/historique";}', '2012-09-13 16:40:55', '2012-09-14 15:12:38'),
(56, 2, 21, 'Story', 'story', 1, 'a:2:{i:0;s:13:"ch/home/story";i:1;s:13:"fr/home/story";}', '2012-09-13 16:40:55', '2012-09-14 15:12:38'),
(57, 3, 21, 'Geschichte', 'geschichte', 1, 'a:2:{i:0;s:24:"ch/startseite/geschichte";i:1;s:24:"fr/startseite/geschichte";}', '2012-09-13 16:40:55', '2012-09-14 15:12:38'),
(58, 1, 22, 'Nouvelle exposition', 'nouvelle-exposition', 1, 'a:2:{i:0;s:35:"ch/actualites-2/nouvelle-exposition";i:1;s:35:"fr/actualites-2/nouvelle-exposition";}', '2012-09-16 10:46:14', '2012-09-16 18:04:00'),
(59, 2, 22, 'New exposition', 'new-exposition', 1, 'a:2:{i:0;s:22:"ch/news/new-exposition";i:1;s:22:"fr/news/new-exposition";}', '2012-09-16 10:46:14', '2012-09-16 18:04:00'),
(60, 3, 22, 'New exposition', 'new-exposition-1', 1, 'a:2:{i:0;s:23:"ch/nueue/new-exposition";i:1;s:23:"fr/nueue/new-exposition";}', '2012-09-16 10:46:14', '2012-09-16 18:04:00');

-- --------------------------------------------------------

--
-- Structure de la table `content_category`
--

CREATE TABLE IF NOT EXISTS `content_category` (
  `contenttranslation_id` int(11) NOT NULL,
  `categorytranslation_id` int(11) NOT NULL,
  PRIMARY KEY (`contenttranslation_id`,`categorytranslation_id`),
  KEY `IDX_54FBF32E68204D1A` (`contenttranslation_id`),
  KEY `IDX_54FBF32E2D214E40` (`categorytranslation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `content_category`
--

INSERT INTO `content_category` (`contenttranslation_id`, `categorytranslation_id`) VALUES
(28, 10),
(29, 11),
(30, 12),
(31, 10),
(32, 11),
(33, 12),
(34, 1),
(34, 16),
(35, 2),
(36, 3),
(37, 19),
(38, 20),
(39, 21),
(40, 1),
(40, 16),
(41, 2),
(42, 3),
(46, 13),
(47, 14),
(48, 15),
(49, 19),
(50, 20),
(51, 21),
(52, 13),
(53, 14),
(54, 15),
(55, 25),
(56, 23),
(57, 24),
(58, 1),
(59, 2),
(60, 3);

-- --------------------------------------------------------

--
-- Structure de la table `content_country`
--

CREATE TABLE IF NOT EXISTS `content_country` (
  `contenttranslation_id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  PRIMARY KEY (`contenttranslation_id`,`country_id`),
  KEY `IDX_8C7B10D568204D1A` (`contenttranslation_id`),
  KEY `IDX_8C7B10D5F92F3E70` (`country_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `content_country`
--

INSERT INTO `content_country` (`contenttranslation_id`, `country_id`) VALUES
(28, 1),
(28, 2),
(29, 1),
(29, 2),
(30, 1),
(30, 2),
(31, 1),
(31, 2),
(32, 1),
(32, 2),
(33, 1),
(33, 2),
(34, 1),
(34, 2),
(35, 1),
(35, 2),
(36, 1),
(36, 2),
(37, 1),
(37, 2),
(38, 1),
(38, 2),
(39, 1),
(39, 2),
(40, 1),
(40, 2),
(41, 1),
(41, 2),
(42, 1),
(42, 2),
(46, 1),
(46, 2),
(47, 1),
(47, 2),
(48, 1),
(48, 2),
(49, 1),
(49, 2),
(50, 1),
(50, 2),
(51, 1),
(51, 2),
(52, 1),
(52, 2),
(53, 1),
(53, 2),
(54, 1),
(54, 2),
(55, 1),
(55, 2),
(56, 1),
(56, 2),
(57, 1),
(57, 2),
(58, 1),
(58, 2),
(59, 1),
(59, 2),
(60, 1),
(60, 2);

-- --------------------------------------------------------

--
-- Structure de la table `country`
--

CREATE TABLE IF NOT EXISTS `country` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `code` varchar(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `country`
--

INSERT INTO `country` (`id`, `name`, `code`) VALUES
(1, 'Suisse', 'ch'),
(2, 'France', 'fr');

-- --------------------------------------------------------

--
-- Structure de la table `dico`
--

CREATE TABLE IF NOT EXISTS `dico` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clef` varchar(255) NOT NULL,
  `libelle` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Contenu de la table `dico`
--

INSERT INTO `dico` (`id`, `clef`, `libelle`) VALUES
(1, 'objet_demande', 'Prêt'),
(2, 'situation_actuelle', 'Je réside déjà en suisse'),
(3, 'rappel_telephonique', 'En matinée');

-- --------------------------------------------------------

--
-- Structure de la table `error_url`
--

CREATE TABLE IF NOT EXISTS `error_url` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `code` int(11) NOT NULL,
  `url_dest` varchar(255) DEFAULT NULL,
  `nb` int(11) NOT NULL,
  `last_accessed` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Contenu de la table `error_url`
--

INSERT INTO `error_url` (`id`, `url`, `code`, `url_dest`, `nb`, `last_accessed`) VALUES
(1, '/fr/fr/', 301, '/fr/fr', 2, '2012-09-17 16:35:53'),
(3, '/admin', 404, NULL, 0, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Structure de la table `ext_translations`
--

CREATE TABLE IF NOT EXISTS `ext_translations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `locale` varchar(8) NOT NULL,
  `object_class` varchar(255) NOT NULL,
  `field` varchar(32) NOT NULL,
  `foreign_key` varchar(64) NOT NULL,
  `content` longtext,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lookup_unique_idx` (`locale`,`object_class`,`field`,`foreign_key`),
  KEY `translations_lookup_idx` (`locale`,`object_class`,`foreign_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `fields`
--

CREATE TABLE IF NOT EXISTS `fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_field_taxonomy` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `libelle` varchar(255) NOT NULL,
  `ordre` int(11) NOT NULL,
  `required` tinyint(1) NOT NULL,
  `published` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_7EE5E388164C82F6` (`id_field_taxonomy`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=29 ;

--
-- Contenu de la table `fields`
--

INSERT INTO `fields` (`id`, `id_field_taxonomy`, `name`, `libelle`, `ordre`, `required`, `published`) VALUES
(11, 1, 'rue', 'Rue', 1, 0, 1),
(12, 1, 'code_postal', 'Code postal', 2, 0, 1),
(13, 1, 'ville', 'Ville', 3, 0, 1),
(14, 1, 'pays', 'Pays', 5, 0, 1),
(15, 1, 'latitude', 'Latitude', 7, 0, 1),
(16, 1, 'longitude', 'Longitude', 8, 0, 1),
(17, 3, 'description', 'Description', 11, 0, 1),
(18, 1, 'region', 'Région', 6, 0, 1),
(19, 1, 'telephone', 'Téléphone', 9, 0, 1),
(20, 1, 'fax', 'Fax', 10, 0, 1),
(21, 3, 'corps-texte', 'Corps du texte', 12, 0, 1),
(22, 9, 'date_news', 'Date', 13, 0, 1),
(23, 9, 'debut_valid', 'Début de validité', 14, 0, 1),
(24, 9, 'fin_valid', 'Fin de validité', 15, 0, 1),
(25, 3, 'description_courte', 'Description courte', 16, 0, 1),
(26, 6, 'image', 'Image', 18, 0, 1),
(27, 7, 'fichier', 'Fichier', 19, 0, 1),
(28, 1, 'adresse', 'Adresse', 4, 0, 1);

-- --------------------------------------------------------

--
-- Structure de la table `fieldsvalue`
--

CREATE TABLE IF NOT EXISTS `fieldsvalue` (
  `field_id` int(11) NOT NULL,
  `content_translation_id` int(11) NOT NULL,
  `value` longtext NOT NULL,
  PRIMARY KEY (`field_id`,`content_translation_id`),
  KEY `IDX_46BE0B82443707B0` (`field_id`),
  KEY `IDX_46BE0B82F641D1F1` (`content_translation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `fieldsvalue`
--

INSERT INTO `fieldsvalue` (`field_id`, `content_translation_id`, `value`) VALUES
(11, 46, 's:11:"test rue fr";'),
(11, 47, 's:22:"Rue de Chantepoulet 25";'),
(11, 48, 's:11:"test rue de";'),
(11, 52, 's:22:"Rue de Chantepoulet 25";'),
(11, 53, 's:22:"Rue de Chantepoulet 25";'),
(11, 54, 's:11:"test rue de";'),
(12, 46, 's:4:"1201";'),
(12, 47, 's:4:"1201";'),
(12, 48, 's:4:"1201";'),
(12, 52, 's:4:"1201";'),
(12, 53, 's:4:"1207";'),
(12, 54, 's:0:"";'),
(13, 46, 's:7:"Genève";'),
(13, 47, 's:6:"Geneva";'),
(13, 48, 's:4:"Genf";'),
(13, 52, 's:7:"Genève";'),
(13, 53, 's:7:"Genève";'),
(13, 54, 's:0:"";'),
(14, 46, 's:6:"Suisse";'),
(14, 47, 's:11:"Switzerland";'),
(14, 48, 's:7:"Schweiz";'),
(14, 52, 's:6:"Suisse";'),
(14, 53, 's:0:"";'),
(14, 54, 's:0:"";'),
(15, 46, 's:10:"9.52148793";'),
(15, 47, 's:10:"9.52133698";'),
(15, 48, 's:10:"9.52135597";'),
(15, 52, 's:10:"9.52148793";'),
(15, 53, 's:0:"";'),
(15, 54, 's:0:"";'),
(16, 46, 's:10:"46.5212369";'),
(16, 47, 's:10:"46.2145873";'),
(16, 48, 's:10:"46.2245878";'),
(16, 52, 's:10:"46.5212369";'),
(16, 53, 's:0:"";'),
(16, 54, 's:0:"";'),
(17, 34, 's:452:"<p>\r\n	Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis.</p>\r\n<p>\r\n	At vero eos et accusam et justo duo dolores et ea rebum. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.</p>\r\n";'),
(17, 35, 's:0:"";'),
(17, 36, 's:0:"";'),
(17, 37, 's:2196:"<p>\r\n	Lorem ipsum dolor sit amet, consetetur sadipscing elitr, At accusam aliquyam diam diam dolore dolores duo eirmod eos erat, et nonumy sed tempor et et invidunt justo labore Stet clita ea et gubergren, kasd magna no rebum.</p>\r\n<p>\r\n	Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi.</p>\r\n<p>\r\n	Consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Excepteur sint obcaecat cupiditat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.</p>\r\n<p>\r\n	Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.</p>\r\n<h2 style="color:#e6690d;font-size:16px;margin:10px 0;font-style:normal;">\r\n	Vous &ecirc;tes :&nbsp;</h2>\r\n<table width="100%">\r\n	<tbody>\r\n		<tr>\r\n			<td style="border-right:1px solid #ccc">\r\n				<p style="text-align: center; ">\r\n					R&eacute;sidents<r&eacute;sidents< p=""></r&eacute;sidents<></p>\r\n				<p style="text-align: center; ">\r\n					<img alt="" src="/web/uploads/content/fr/fr/resident.png" style="width: 69px; height: 71px; " /></p>\r\n			</td>\r\n			<td style="border-right:1px solid #ccc">\r\n				<p style="text-align: center; ">\r\n					Frontaliers</p>\r\n				<p style="text-align: center; ">\r\n					<img alt="" src="/web/uploads/content/fr/fr/frontalier.png" style="width: 86px; height: 70px; " /></p>\r\n			</td>\r\n			<td>\r\n				<p style="text-align: center; ">\r\n					Expatri&eacute;s</p>\r\n				<p style="text-align: center; ">\r\n					<img alt="" src="/web/uploads/content/fr/fr/expatri%C3%A9.png" style="width: 94px; height: 71px; " /></p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n<p>\r\n	&nbsp;</p>\r\n";'),
(17, 38, 's:0:"";'),
(17, 39, 's:0:"";'),
(17, 40, 's:1749:"<p>\r\n	<span class="ShortDescription" id="dnn_ctr436_ViewNews_lblShortDesc" style="padding-top: 7px; font-family: sans-serif; color: gray; ">Jusqu&#39;au 31 ao&ucirc;t 2012, b&eacute;n&eacute;ficiez d&#39;un taux fixe 10 ans de 1.99%.</span></p>\r\n<p style="margin: 0px; padding: 0px; ">\r\n	Du 1er au 31 ao&ucirc;t 2012, profitez d&rsquo;un taux tr&egrave;s attractif sur votre pr&ecirc;t hypoth&eacute;caire sur 10 ans.</p>\r\n<p style="margin: 0px; padding: 0px; ">\r\n	&nbsp;</p>\r\n<p style="margin: 0px; padding: 0px; ">\r\n	Cr&eacute;dit Agricole Financements (Suisse) SA vous fait b&eacute;n&eacute;ficier d&rsquo;une promotion sur son&nbsp;<a href="http://www.ca-financements.ch/prets-hypothecaires-sur-10-ans-a-taux-tres-attractif.html" style="text-decoration: none; color: rgb(2, 132, 153); ">taux hypoth&eacute;caire fixe &agrave; 1.99%</a>.</p>\r\n<p style="margin: 0px; padding: 0px; ">\r\n	&nbsp;</p>\r\n<p style="margin: 0px; padding: 0px; ">\r\n	Vous pouvez profiter de r&eacute;ductions suppl&eacute;mentaires si votre pr&ecirc;t est assorti de solutions d&rsquo;&eacute;pargne et/ou de pr&eacute;voyance aupr&egrave;s de notre &eacute;tablissement.</p>\r\n<p style="margin: 0px; padding: 0px; ">\r\n	&nbsp;</p>\r\n<p style="margin: 0px; padding: 0px; ">\r\n	Prenez d&egrave;s &agrave; pr&eacute;sent contact avec un de nos conseillers sp&eacute;cialis&eacute;s et&nbsp;<a href="http://www.ca-financements.ch/prets-hypothecaires-sur-10-ans-a-taux-tres-attractif.html" style="text-decoration: none; color: rgb(2, 132, 153); ">profitez de ce taux exceptionnel</a>.</p>\r\n<p style="margin: 0px; padding: 0px; ">\r\n	&nbsp;</p>\r\n<p style="margin: 0px; padding: 0px; ">\r\n	Offre valable pour toute demande de pr&ecirc;t initi&eacute;e avant le 31 ao&ucirc;t2012.</p>\r\n";'),
(17, 41, 's:0:"";'),
(17, 42, 's:0:"";'),
(17, 49, 's:3160:"<p>\r\n	&nbsp;<span style="color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; ">&bull; Date de naissance :&nbsp;novembre 2000 </span></p>\r\n<p style="margin: 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; ">\r\n	&bull; Capital :&nbsp;236 mio CHF <br />\r\n	&bull; 15&#39;000 clients <br />\r\n	&bull;&nbsp;130 collaborateurs <br />\r\n	&bull;&nbsp;9 agences :&nbsp;3 &agrave; Gen&egrave;ve, 1 &agrave; Lausanne, 1 &agrave; Fribourg, 1 &agrave; B&acirc;le, 1 &agrave; Neuch&acirc;tel,1 &agrave; Yverdon-les-Bains et&nbsp;1 &agrave; la Chaux-de-Fonds.</p>\r\n<p style="margin: 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; ">\r\n	&nbsp;</p>\r\n<p style="margin: 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; ">\r\n	Cr&eacute;dit Agricole Financements (Suisse) SA :<br />\r\n	- fait partie du Groupe Cr&eacute;dit Agricole<br />\r\n	- est une banque de droit suisse d&eacute;tenue par&nbsp;5 actionnaires :<br />\r\n	&nbsp;&nbsp;<span style="color: rgb(0, 128, 128); ">&gt;</span>&nbsp;Caisse R&eacute;gionale de&nbsp;<span style="color: rgb(0, 128, 128); "><a href="http://www.ca-des-savoie.fr/" style="text-decoration: none; color: rgb(2, 132, 153); " target="_blank">Cr&eacute;dit Agricole des Savoie</a><br />\r\n	&nbsp; &gt;&nbsp;</span>Caisse R&eacute;gionale de&nbsp;<span style="color: rgb(0, 128, 128); "><a href="http://www.ca-centrest.fr/" style="text-decoration: none; color: rgb(2, 132, 153); " target="_blank">Cr&eacute;dit Agricole Centre-Est</a></span></p>\r\n<p style="margin: 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; ">\r\n	<span style="color: rgb(0, 128, 128); ">&nbsp; &gt;&nbsp;<font color="#000000">Caisse R&eacute;gionale de&nbsp;</font><font color="#008080">Cr&eacute;dit Agricole de Franche-Comt&eacute;</font></span></p>\r\n<p style="margin: 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; ">\r\n	&nbsp;</p>\r\n<p style="margin: 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; ">\r\n	&nbsp;</p>\r\n<p style="margin: 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; ">\r\n	<span style="color: rgb(0, 128, 128); "><font color="#008080">&nbsp;&nbsp;</font>&gt;&nbsp;</span><a href="http://www.ca-suisse.com/" style="text-decoration: none; color: rgb(2, 132, 153); " target="_blank"><span style="color: rgb(0, 128, 128); ">Cr&eacute;dit Agricole (Suisse) SA</span></a></p>\r\n<p style="margin: 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; ">\r\n	&nbsp;</p>\r\n<p style="margin: 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; ">\r\n	&nbsp;</p>\r\n<p style="margin: 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; ">\r\n	&nbsp;</p>\r\n<p style="margin: 0px; padding: 0px; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; ">\r\n	<span style="color: rgb(0, 128, 128); ">&nbsp; &gt;&nbsp;<font color="#000000">Caisse R&eacute;gionale de&nbsp;</font><font color="#008080">Alsace-Vosges</font></span></p>\r\n";'),
(17, 50, 's:0:"";'),
(17, 51, 's:0:"";'),
(17, 55, 's:1535:"<p>\r\n	<span class="DNNAlignleft" id="dnn_ctr468_ContentPane">Historiquement tr&egrave;s pr&eacute;sent en France, le <strong>Cr&eacute;dit Agricole f</strong>inance une habitation sur deux dans les r&eacute;gions frontali&egrave;res. Fort d&#39;une exp&eacute;rience de plus de&nbsp;20 ans en Suisse, <a href="http://www.ca-financements.ch/Home/InnerPage/tabid/101/language/fr-FR/Default.aspx?MenuID=13">Cr&eacute;dit Agricole Financements (Suisse)</a> SA met ce savoir-faire &agrave; votre service.<br />\r\n	<br />\r\n	En dix ans, Cr&eacute;dit Agricole Financements (Suisse) SA a r&eacute;ussi &agrave; devenir l&#39;un des acteurs majeurs du march&eacute; immobilier suisse. Implant&eacute; &agrave; Gen&egrave;ve (trois agences), B&acirc;le, <strong>Lausanne</strong>, <strong>Fribourg</strong>, <strong>Yverdon</strong>, <strong>Neuch&acirc;tel</strong> et la Chaux-de-Fonds, Cr&eacute;dit Agricole Financements apporte en permanence une prestation de tr&egrave;s haut niveau, gr&acirc;ce &agrave; des conseillers experts dans toutes les techniques du financement de l&#39;habitat. Ceux-ci proposent aux particuliers des solutions de financement sur mesure pour l&#39;acquisition ou la construction d&#39;une r&eacute;sidence principale, secondaire ou locative en Suisse et&nbsp;en France.</span></p>\r\n<p>\r\n	<br />\r\n	<span class="DNNAlignleft" id="dnn_ctr468_ContentPane">Depuis 2009, Cr&eacute;dit Agricole Financements lance la banque de d&eacute;tail et propose des produits et services bancaires utiles au quotidien.</span></p>\r\n";'),
(17, 56, 's:0:"";'),
(17, 57, 's:1474:"<p>\r\n	&nbsp;</p>\r\n<p>\r\n	Innerhalb von acht Jahren ist es Cr&eacute;dit Agricole Financements (Suisse) SA gelungen, sich als einer der gr&ouml;ssten Akteure auf dem schweizerischen Immobilienmarkt zu etablieren.<br />\r\n	<br />\r\n	Eine langj&auml;hrige Erfahrung bei der Immobilienfinanzierung<br />\r\n	<br />\r\n	Der Cr&eacute;dit Agricole kann in Frankreich auf eine lange, erfolgreiche Geschichte zur&uuml;ckblicken und finanziert in den Grenzregionen bereits jedes zweite Wohneigentum. Gest&uuml;tzt auf mehr als 16 Jahre Erfahrung in der Schweiz stellt Ihnen Cr&eacute;dit Agricole Financements (Suisse) SA sein Know-how zur Verf&uuml;gung.<br />\r\n	<br />\r\n	Cr&eacute;dit Agricole Financements ist die einzige Bank, die sich ausschliesslich auf Immobilienkredite konzentriert.<br />\r\n	<br />\r\n	Spezialisten an Ihrer Seite<br />\r\n	<br />\r\n	Die fachkundigen Berater von Cr&eacute;dit Agricole Financements in den Niederlassungen in Genf (3 Filialen), Basel, Lausanne und Freiburg sorgen im Hinblick auf die Finanzierung von Wohneigentum in allen Bereichen f&uuml;r einen erstklassigen Service. Sie bieten Privatpersonen massgeschneiderte Finanzierungsl&ouml;sungen f&uuml;r den Erwerb oder den Bau eines Haupt- oder Zweitwohnsitzes oder eines Mietobjekts in der Schweiz und&nbsp;in Frankreich.<br />\r\n	<br />\r\n	Unser Ziel ist es, so vielen Privatpersonen wie m&ouml;glich den Traum vom Eigenheim zu erf&uuml;llen.<br />\r\n	<br />\r\n	Unsere T&auml;tigkeit : DIE FINANZIERUNG</p>\r\n";'),
(17, 58, 's:339:"<p>\r\n	Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. At vero eos et accusam et justo duo dolores et ea rebum.</p>\r\n";'),
(17, 59, 's:276:"<p>\r\n	Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.</p>\r\n";'),
(17, 60, 's:125:"<p>\r\n	At vero eos et accusam et justo duo dolores et ea rebum. At vero eos et accusam et justo duo dolores et ea rebum.</p>\r\n";'),
(18, 34, 's:0:"";'),
(18, 35, 's:0:"";'),
(18, 36, 's:0:"";'),
(18, 40, 's:0:"";'),
(18, 41, 's:0:"";'),
(18, 42, 's:0:"";'),
(18, 58, 's:0:"";'),
(18, 59, 's:0:"";'),
(18, 60, 's:0:"";'),
(19, 46, 's:11:"41227376400";'),
(19, 47, 's:11:"41227376400";'),
(19, 48, 's:11:"41227376400";'),
(19, 52, 's:19:"+41 (0)22 737 64 00";'),
(19, 53, 's:11:"41227376500";'),
(19, 54, 's:0:"";'),
(20, 46, 's:0:"";'),
(20, 47, 's:0:"";'),
(20, 48, 's:0:"";'),
(20, 52, 's:19:"+41 (0)22 738 25 80";'),
(20, 53, 's:0:"";'),
(20, 54, 's:0:"";'),
(21, 28, 's:483:"<p>\r\n	At vero eos et accusam et justo duo dolores et ea rebum. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquid ex ea commodi consequat. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>\r\n<p>\r\n	Lorem ipsum dolor sit amet. At vero eos et accusam et justo duo dolores et ea rebum. Consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.</p>\r\n";'),
(21, 29, 's:0:"";'),
(21, 30, 's:0:"";'),
(21, 31, 's:580:"<p>\r\n	Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. At vero eos et accusam et justo duo dolores et ea rebum. Consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>\r\n";'),
(21, 32, 's:670:"<p>\r\n	Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>\r\n<p>\r\n	Consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi.</p>\r\n";'),
(21, 33, 's:584:"<p>\r\n	Quis aute iure reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>\r\n<p>\r\n	Excepteur sint obcaecat cupiditat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>\r\n<p>\r\n	At vero eos et accusam et justo duo dolores et ea rebum. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>\r\n";'),
(21, 34, 's:1260:"<p>\r\n	Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquid ex ea commodi consequat. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>\r\n<p>\r\n	Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>\r\n<p>\r\n	Consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.. Lorem ipsum dolor sit amet, consectetur adipisici elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua.</p>\r\n<p>\r\n	Consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, At accusam aliquyam diam diam dolore dolores duo eirmod eos erat, et nonumy sed tempor et et invidunt justo labore Stet clita ea et gubergren, kasd magna no rebum.</p>\r\n";'),
(21, 35, 's:0:"";'),
(21, 36, 's:0:"";'),
(21, 40, 's:0:"";'),
(21, 41, 's:0:"";'),
(21, 42, 's:0:"";'),
(21, 58, 's:1432:"<p>\r\n	Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi.</p>\r\n<p>\r\n	Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat.</p>\r\n<p>\r\n	At vero eos et accusam et justo duo dolores et ea rebum. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.</p>\r\n<p>\r\n	Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi.</p>\r\n";'),
(21, 59, 's:818:"<p>\r\n	Sanctus sea sed takimata ut vero voluptua. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consectetur adipisici elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis.</p>\r\n<p>\r\n	At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Excepteur sint obcaecat cupiditat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>\r\n";'),
(21, 60, 's:1079:"<p>\r\n	Consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquid ex ea commodi consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi.</p>\r\n<p>\r\n	At vero eos et accusam et justo duo dolores et ea rebum. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum.</p>\r\n<p>\r\n	&nbsp;At vero eos et accusam et justo duo dolores et ea rebum. At vero eos et accusam et justo duo dolores et ea rebum. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>\r\n";'),
(22, 34, 's:10:"2012/08/26";'),
(22, 35, 's:0:"";'),
(22, 36, 's:0:"";'),
(22, 40, 's:10:"2012/08/25";'),
(22, 41, 's:0:"";'),
(22, 42, 's:0:"";'),
(22, 58, 's:10:"2012/09/02";'),
(22, 59, 's:10:"2012/09/15";'),
(22, 60, 's:10:"2012/09/15";'),
(23, 34, 's:10:"2012/08/25";'),
(23, 35, 's:0:"";'),
(23, 36, 's:0:"";'),
(23, 40, 's:10:"2012/09/02";'),
(23, 41, 's:0:"";'),
(23, 42, 's:0:"";'),
(23, 58, 's:10:"2012/08/25";'),
(23, 59, 's:10:"2012/09/13";'),
(23, 60, 's:10:"2012/09/13";'),
(24, 34, 's:10:"2012/09/14";'),
(24, 35, 's:0:"";'),
(24, 36, 's:0:"";'),
(24, 40, 's:10:"2012/09/21";'),
(24, 41, 's:0:"";'),
(24, 42, 's:0:"";'),
(24, 58, 's:10:"2012/09/21";'),
(24, 59, 's:10:"2012/09/29";'),
(24, 60, 's:10:"2012/09/29";'),
(25, 28, 's:124:"<p>\r\n	At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est.</p>\r\n";'),
(25, 29, 's:0:"";'),
(25, 30, 's:0:"";'),
(25, 31, 's:151:"<p>\r\n	Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. At vero eos et accusam et justo duo dolores et ea rebum.</p>\r\n";'),
(25, 32, 's:266:"<p>\r\n	Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat. Lorem ipsum dolor sit amet, consectetur adipisici elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua.</p>\r\n";'),
(25, 33, 's:148:"<p>\r\n	Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat.</p>\r\n";'),
(25, 46, 's:436:"<p>\r\n	Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Quis aute iure reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>\r\n<p>\r\n	At vero eos et accusam et justo duo dolores et ea rebum. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquid ex ea commodi consequat.</p>\r\n";'),
(25, 47, 's:659:"<p>\r\n	At vero eos et accusam et justo duo dolores et ea rebum. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.</p>\r\n<p>\r\n	Stet clita kasd gubergren, no sea takimata sanctus est. At vero eos et accusam et justo duo dolores et ea rebum. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>\r\n";'),
(25, 48, 's:0:"";'),
(25, 52, 's:298:"<p>\r\n	<strong>Horaires d&#39;ouverture :</strong><br />\r\n	Du lundi au mercredi : 8h30 - 12h30 / 13h15 - 17h30<br />\r\n	Le jeudi : 9h30 - 12h30 / 13h15 - 18h45 (nocturne)<br />\r\n	Le vendredi : 8h30 - 12h30 / 13h15 - 17h00</p>\r\n<p>\r\n	<strong>Directeur d&#39;agence :&nbsp;</strong>Philippe Brand</p>\r\n";'),
(25, 53, 's:0:"";'),
(25, 54, 's:0:"";'),
(26, 34, 'a:3:{s:3:"alt";s:29:"Nouvelle plateforme e-banking";s:5:"title";s:29:"Nouvelle plateforme e-banking";s:5:"image";s:40:"uploads/content/fr/fr/504e021435f47.jpeg";}'),
(26, 35, 'a:3:{s:3:"alt";s:0:"";s:5:"title";s:0:"";s:5:"image";N;}'),
(26, 36, 'a:3:{s:3:"alt";s:0:"";s:5:"title";s:0:"";s:5:"image";N;}'),
(26, 40, 'a:3:{s:3:"alt";s:0:"";s:5:"title";s:0:"";s:5:"image";s:40:"uploads/content/fr/fr/5050521cea42b.jpeg";}'),
(26, 41, 'a:3:{s:3:"alt";s:0:"";s:5:"title";s:0:"";s:5:"image";N;}'),
(26, 42, 'a:3:{s:3:"alt";s:0:"";s:5:"title";s:0:"";s:5:"image";N;}'),
(26, 46, 'a:3:{s:3:"alt";s:6:"agence";s:5:"title";s:15:"test title edit";s:5:"image";s:40:"uploads/content/fr/fr/50517efbcaddb.jpeg";}'),
(26, 47, 'a:3:{s:3:"alt";s:0:"";s:5:"title";s:0:"";s:5:"image";s:40:"uploads/content/en/en/50534814292e9.jpeg";}'),
(26, 48, 'a:3:{s:3:"alt";s:0:"";s:5:"title";s:0:"";s:5:"image";s:40:"uploads/content/de/de/505348142f77d.jpeg";}'),
(26, 52, 'a:3:{s:3:"alt";s:23:"Agence Genève Cornavin";s:5:"title";s:23:"Agence Genève Cornavin";s:5:"image";s:40:"uploads/content/fr/fr/505186602f7c8.jpeg";}'),
(26, 53, 'a:3:{s:3:"alt";s:0:"";s:5:"title";s:0:"";s:5:"image";N;}'),
(26, 54, 'a:3:{s:3:"alt";s:0:"";s:5:"title";s:0:"";s:5:"image";N;}'),
(26, 58, 'a:3:{s:3:"alt";s:0:"";s:5:"title";s:0:"";s:5:"image";s:40:"uploads/content/fr/fr/505591d6c0bd9.jpeg";}'),
(26, 59, 'a:3:{s:3:"alt";s:0:"";s:5:"title";s:0:"";s:5:"image";s:40:"uploads/content/en/en/505591d6c1f94.jpeg";}'),
(26, 60, 'a:3:{s:3:"alt";s:0:"";s:5:"title";s:0:"";s:5:"image";s:40:"uploads/content/de/de/505591d6c327e.jpeg";}'),
(27, 28, 's:0:"";'),
(27, 29, 's:0:"";'),
(27, 30, 's:0:"";'),
(27, 31, 's:0:"";'),
(27, 32, 's:0:"";'),
(27, 33, 's:0:"";'),
(28, 46, 's:0:"";'),
(28, 47, 's:0:"";'),
(28, 48, 's:0:"";'),
(28, 52, 's:26:"CP 1314 – 1211 Genève 1";'),
(28, 53, 's:0:"";'),
(28, 54, 's:0:"";');

-- --------------------------------------------------------

--
-- Structure de la table `fields_content_taxonomy`
--

CREATE TABLE IF NOT EXISTS `fields_content_taxonomy` (
  `fields_id` int(11) NOT NULL,
  `contenttaxonomy_id` int(11) NOT NULL,
  PRIMARY KEY (`fields_id`,`contenttaxonomy_id`),
  KEY `IDX_8469A872C5439AE` (`fields_id`),
  KEY `IDX_8469A876F25A07C` (`contenttaxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `fields_content_taxonomy`
--

INSERT INTO `fields_content_taxonomy` (`fields_id`, `contenttaxonomy_id`) VALUES
(11, 2),
(12, 2),
(13, 2),
(14, 2),
(15, 2),
(16, 2),
(17, 1),
(17, 4),
(17, 5),
(18, 1),
(19, 2),
(20, 2),
(21, 1),
(21, 3),
(22, 1),
(23, 1),
(24, 1),
(25, 2),
(25, 3),
(26, 1),
(26, 2),
(27, 3),
(28, 2);

-- --------------------------------------------------------

--
-- Structure de la table `fieldtaxonomy`
--

CREATE TABLE IF NOT EXISTS `fieldtaxonomy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `balise` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Contenu de la table `fieldtaxonomy`
--

INSERT INTO `fieldtaxonomy` (`id`, `name`, `balise`) VALUES
(1, 'Text', '<input type="text" name="#2#1" value="#3" />'),
(3, 'Textarea', '<textarea name="#2#1" class="tinymce">#3</textarea>'),
(5, 'Number', '<input type="text" name="#2#1" value="#3" class="required required-number" />'),
(6, 'Image', '<input type="file" name="#2#1" class="required-image" />'),
(7, 'File', '<input type="file" name="#2#1" />'),
(8, 'URL', '<input type="url" name="#2#1" class="required required-url" />'),
(9, 'Date', '<input type="date" name="#2#1" />');

-- --------------------------------------------------------

--
-- Structure de la table `formfields`
--

CREATE TABLE IF NOT EXISTS `formfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_form_field_taxonomy` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `libelle` varchar(255) NOT NULL,
  `ordre` int(11) NOT NULL,
  `required` tinyint(1) NOT NULL,
  `published` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_779AABD7DB055841` (`id_form_field_taxonomy`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Contenu de la table `formfields`
--

INSERT INTO `formfields` (`id`, `id_form_field_taxonomy`, `name`, `libelle`, `ordre`, `required`, `published`) VALUES
(1, 3, 'champ_textarea', 'champ textarea', 1, 0, 1),
(2, 1, 'champ_text', 'champ text', 2, 1, 1),
(3, 8, 'champ_date', 'champ date', 3, 1, 1),
(4, 4, 'num_compte', 'numéro compte', 4, 0, 1);

-- --------------------------------------------------------

--
-- Structure de la table `formfieldsvalue`
--

CREATE TABLE IF NOT EXISTS `formfieldsvalue` (
  `formfield_id` int(11) NOT NULL,
  `formulaire_id` int(11) NOT NULL,
  `value` longtext NOT NULL,
  PRIMARY KEY (`formfield_id`,`formulaire_id`),
  KEY `IDX_2C32B76E11386F6` (`formfield_id`),
  KEY `IDX_2C32B76E5053569B` (`formulaire_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `formfieldsvalue`
--

INSERT INTO `formfieldsvalue` (`formfield_id`, `formulaire_id`, `value`) VALUES
(1, 1, '<h3 style="color:red;">\r\n	<strong>textarea</strong></h3>\r\n'),
(1, 2, '<p>\r\n	mon test 1 2 3</p>\r\n'),
(2, 1, 'mon texte'),
(3, 1, '12/02/2012');

-- --------------------------------------------------------

--
-- Structure de la table `formfieldtaxonomy`
--

CREATE TABLE IF NOT EXISTS `formfieldtaxonomy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `balise` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Contenu de la table `formfieldtaxonomy`
--

INSERT INTO `formfieldtaxonomy` (`id`, `name`, `balise`) VALUES
(1, 'Text', '<input type="text" name="#2#1" value="#3" />'),
(3, 'Textarea', '<textarea name="#2#1" class="tinymce">#3</textarea'),
(4, 'Number', '<input type="text" name="#2#1" value="#3" class="required required-number" />'),
(5, 'Image', '<input type="file" name="#2#1" class="required-image" />'),
(6, 'File', '<input type="file" name="#2#1" />'),
(7, 'URL', '<input type="url" name="#2#1" class="required required-url" />'),
(8, 'Date', '<input type="date" name="#2#1" />');

-- --------------------------------------------------------

--
-- Structure de la table `formtaxonomy`
--

CREATE TABLE IF NOT EXISTS `formtaxonomy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(255) NOT NULL,
  `published` tinyint(1) NOT NULL,
  `template` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `formtaxonomy`
--

INSERT INTO `formtaxonomy` (`id`, `libelle`, `published`, `template`) VALUES
(1, 'Formulaire test', 1, NULL),
(2, 'Formulaire de flo', 1, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `formulaire`
--

CREATE TABLE IF NOT EXISTS `formulaire` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_form_taxonomy` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `published` tinyint(1) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_5BDD01A8F200EC1C` (`id_form_taxonomy`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `formulaire`
--

INSERT INTO `formulaire` (`id`, `id_form_taxonomy`, `title`, `published`, `created`, `updated`) VALUES
(1, 1, 'Titre formulaire n°1', 1, '2012-08-31 11:31:35', '2012-08-31 11:32:02'),
(2, 2, 'test formulaire values form', 1, '2012-09-04 12:38:01', '2012-09-04 12:38:01');

-- --------------------------------------------------------

--
-- Structure de la table `formulairecrm`
--

CREATE TABLE IF NOT EXISTS `formulairecrm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nomform` varchar(255) NOT NULL,
  `currentStatut_id` int(11) NOT NULL,
  `currentTypeEmail_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_ADC83951C76985ED` (`currentStatut_id`),
  UNIQUE KEY `UNIQ_ADC83951F575EFC8` (`currentTypeEmail_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `formulairecrm`
--

INSERT INTO `formulairecrm` (`id`, `nomform`, `currentStatut_id`, `currentTypeEmail_id`) VALUES
(1, 'Test formulaire 1', 3, 31);

-- --------------------------------------------------------

--
-- Structure de la table `form_fields_taxonomy`
--

CREATE TABLE IF NOT EXISTS `form_fields_taxonomy` (
  `formfields_id` int(11) NOT NULL,
  `formtaxonomy_id` int(11) NOT NULL,
  PRIMARY KEY (`formfields_id`,`formtaxonomy_id`),
  KEY `IDX_D3D6C550B3AEF98A` (`formfields_id`),
  KEY `IDX_D3D6C550FFDB5A1A` (`formtaxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `form_fields_taxonomy`
--

INSERT INTO `form_fields_taxonomy` (`formfields_id`, `formtaxonomy_id`) VALUES
(1, 1),
(1, 2),
(2, 1),
(3, 1),
(4, 1);

-- --------------------------------------------------------

--
-- Structure de la table `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `role` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_F06D397057698A6A` (`role`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `groups`
--

INSERT INTO `groups` (`id`, `name`, `role`) VALUES
(1, 'Administrateur', 'ROLE_ADMIN'),
(2, 'User', 'ROLE_USER');

-- --------------------------------------------------------

--
-- Structure de la table `histoemail`
--

CREATE TABLE IF NOT EXISTS `histoemail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `id_parent` int(11) NOT NULL,
  `emailEnvoyeur` varchar(255) DEFAULT NULL,
  `dateEnvoi` datetime DEFAULT NULL,
  `sujet` varchar(255) DEFAULT NULL,
  `emailClient` varchar(255) DEFAULT NULL,
  `message` longtext,
  `typeEmail_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_33904FA0D2D2D17` (`typeEmail_id`),
  KEY `IDX_33904FA0A76ED395` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=32 ;

--
-- Contenu de la table `histoemail`
--

INSERT INTO `histoemail` (`id`, `user_id`, `id_parent`, `emailEnvoyeur`, `dateEnvoi`, `sujet`, `emailClient`, `message`, `typeEmail_id`) VALUES
(31, 2, 0, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `histostatut`
--

CREATE TABLE IF NOT EXISTS `histostatut` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `agence_id` int(11) DEFAULT NULL,
  `conseiller_id` int(11) DEFAULT NULL,
  `langue_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `dateStatutMAJ` datetime NOT NULL,
  `id_parent` int(11) NOT NULL,
  `daterdv` datetime DEFAULT NULL,
  `dateEnvoi` datetime DEFAULT NULL,
  `racineCompte` varchar(255) DEFAULT NULL,
  `numeroRecommandation` int(11) DEFAULT NULL,
  `commentaire` longtext,
  `statutDemande_id` int(11) NOT NULL,
  `caisseRegionale_id` int(11) DEFAULT NULL,
  `agenceCaisseRegionale_id` int(11) DEFAULT NULL,
  `provenanceDemande_id` int(11) DEFAULT NULL,
  `typeRecommandation_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_640EE44123866917` (`statutDemande_id`),
  KEY `IDX_640EE441D725330D` (`agence_id`),
  KEY `IDX_640EE4411AC39A0D` (`conseiller_id`),
  KEY `IDX_640EE441234847D` (`caisseRegionale_id`),
  KEY `IDX_640EE441DF045DC2` (`agenceCaisseRegionale_id`),
  KEY `IDX_640EE44145BA76BB` (`provenanceDemande_id`),
  KEY `IDX_640EE441B1572176` (`typeRecommandation_id`),
  KEY `IDX_640EE4412AADBACD` (`langue_id`),
  KEY `IDX_640EE441A76ED395` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Contenu de la table `histostatut`
--

INSERT INTO `histostatut` (`id`, `agence_id`, `conseiller_id`, `langue_id`, `user_id`, `dateStatutMAJ`, `id_parent`, `daterdv`, `dateEnvoi`, `racineCompte`, `numeroRecommandation`, `commentaire`, `statutDemande_id`, `caisseRegionale_id`, `agenceCaisseRegionale_id`, `provenanceDemande_id`, `typeRecommandation_id`) VALUES
(3, 1, NULL, 1, NULL, '2012-09-05 13:32:12', 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `language`
--

CREATE TABLE IF NOT EXISTS `language` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `code` varchar(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Contenu de la table `language`
--

INSERT INTO `language` (`id`, `name`, `code`) VALUES
(1, 'Français', 'fr'),
(2, 'English', 'en'),
(3, 'Deutsch', 'de');

-- --------------------------------------------------------

--
-- Structure de la table `menutaxonomy`
--

CREATE TABLE IF NOT EXISTS `menutaxonomy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Contenu de la table `menutaxonomy`
--

INSERT INTO `menutaxonomy` (`id`, `name`, `alias`) VALUES
(1, 'Menu admin', 'menu-admin'),
(2, 'Main menu', 'main-menu'),
(3, 'Menu bannière', 'menu-banniere'),
(4, 'Menu footer', 'menu-footer');

-- --------------------------------------------------------

--
-- Structure de la table `menutranslation_country`
--

CREATE TABLE IF NOT EXISTS `menutranslation_country` (
  `menutranslation_id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  PRIMARY KEY (`menutranslation_id`,`country_id`),
  KEY `IDX_9B98690C95393E9D` (`menutranslation_id`),
  KEY `IDX_9B98690CF92F3E70` (`country_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `menu_country_ext`
--

CREATE TABLE IF NOT EXISTS `menu_country_ext` (
  `menu_id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  PRIMARY KEY (`menu_id`,`country_id`),
  KEY `IDX_5207BEDFCCD7E912` (`menu_id`),
  KEY `IDX_5207BEDFF92F3E70` (`country_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `menu_country_ext`
--

INSERT INTO `menu_country_ext` (`menu_id`, `country_id`) VALUES
(1, 1),
(1, 2),
(2, 1),
(2, 2),
(3, 1),
(3, 2),
(4, 1),
(4, 2),
(5, 1),
(5, 2),
(6, 1),
(6, 2),
(7, 1),
(7, 2),
(8, 1),
(8, 2),
(9, 1),
(9, 2),
(10, 1),
(10, 2),
(11, 1),
(11, 2),
(12, 1),
(12, 2),
(13, 1),
(13, 2),
(14, 1),
(14, 2),
(15, 1),
(15, 2),
(16, 1),
(16, 2),
(17, 1),
(17, 2),
(18, 1),
(18, 2),
(19, 1),
(19, 2),
(20, 1),
(20, 2),
(21, 1),
(21, 2),
(23, 1),
(23, 2),
(24, 1),
(24, 2),
(25, 1),
(25, 2),
(26, 1),
(26, 2),
(27, 1),
(27, 2),
(28, 1),
(28, 2),
(29, 1),
(29, 2),
(30, 1),
(30, 2),
(31, 1),
(31, 2),
(32, 1),
(32, 2),
(33, 1),
(33, 2),
(34, 1),
(34, 2),
(35, 1),
(35, 2),
(36, 1),
(36, 2),
(37, 1),
(37, 2),
(38, 1),
(38, 2),
(39, 1),
(39, 2),
(40, 1),
(40, 2),
(41, 1),
(41, 2),
(42, 1),
(42, 2),
(43, 1),
(43, 2),
(44, 1),
(44, 2),
(45, 1),
(45, 2),
(46, 1),
(46, 2),
(47, 1),
(47, 2),
(48, 1),
(48, 2),
(53, 1),
(53, 2),
(54, 1),
(54, 2),
(55, 1),
(55, 2),
(59, 1),
(59, 2),
(60, 1),
(60, 2),
(61, 1),
(61, 2),
(63, 1),
(63, 2),
(64, 1),
(64, 2),
(65, 1),
(65, 2),
(66, 1),
(66, 2),
(67, 1),
(67, 2),
(68, 1),
(68, 2),
(69, 1),
(69, 2),
(70, 1),
(70, 2),
(71, 1),
(71, 2),
(72, 1),
(72, 2),
(73, 1),
(73, 2),
(74, 1),
(74, 2),
(75, 1),
(75, 2),
(76, 1),
(76, 2),
(77, 1),
(77, 2),
(78, 1),
(78, 2);

-- --------------------------------------------------------

--
-- Structure de la table `menu_ext`
--

CREATE TABLE IF NOT EXISTS `menu_ext` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` int(11) NOT NULL,
  `content` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `id_menu_taxonomy` int(11) DEFAULT NULL,
  `title` varchar(64) NOT NULL,
  `description` longtext,
  `slug` varchar(64) NOT NULL,
  `published` tinyint(1) NOT NULL,
  `link_taxonomy` tinyint(1) NOT NULL,
  `urls` varchar(255) DEFAULT NULL,
  `urls_content` varchar(255) DEFAULT NULL,
  `lft` int(11) NOT NULL,
  `rgt` int(11) NOT NULL,
  `ordre` int(11) DEFAULT NULL,
  `root` int(11) DEFAULT NULL,
  `lvl` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `media` longtext COMMENT '(DC2Type:array)',
  `path` varchar(255) DEFAULT NULL,
  `menu_picto` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_99725830989D9B62` (`slug`),
  KEY `IDX_99725830727ACA70` (`parent_id`),
  KEY `IDX_997258306F6B2CCE` (`id_menu_taxonomy`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=79 ;

--
-- Contenu de la table `menu_ext`
--

INSERT INTO `menu_ext` (`id`, `category`, `content`, `parent_id`, `id_menu_taxonomy`, `title`, `description`, `slug`, `published`, `link_taxonomy`, `urls`, `urls_content`, `lft`, `rgt`, `ordre`, `root`, `lvl`, `created`, `updated`, `media`, `path`, `menu_picto`) VALUES
(1, 0, 0, NULL, 1, 'Contenu', NULL, 'contenu', 1, 1, 'content', NULL, 1, 18, NULL, 1, 0, '2012-08-20 17:27:05', '2012-08-23 09:14:19', 'a:3:{s:5:"image";N;s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(2, 0, 0, 1, 1, 'Catégories', NULL, 'categories', 1, 1, 'categories', NULL, 2, 3, NULL, 1, 1, '2012-08-20 17:27:33', '2012-08-20 22:03:07', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(3, 0, 0, 1, 1, 'Articles', NULL, 'articles', 1, 1, 'content', NULL, 4, 5, NULL, 1, 1, '2012-08-20 17:28:48', '2012-08-20 22:04:06', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(4, 0, 0, 1, 1, 'separator', NULL, 'separator', 1, 1, 'separator', NULL, 8, 9, NULL, 1, 1, '2012-08-20 17:30:56', '2012-08-20 22:04:56', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(5, 0, 0, 1, 1, 'Type de contenu', NULL, 'type-de-contenu', 1, 1, 'content_taxonomy', NULL, 10, 11, NULL, 1, 1, '2012-08-20 17:31:37', '2012-08-20 22:05:43', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(6, 0, 0, 1, 1, 'Champs', NULL, 'champs', 1, 1, 'fields', NULL, 12, 13, NULL, 1, 1, '2012-08-20 17:32:07', '2012-08-20 22:06:11', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(7, 0, 0, 1, 1, 'separator', NULL, 'separator-1', 1, 1, 'separator', NULL, 14, 15, NULL, 1, 1, '2012-08-20 17:34:51', '2012-08-20 22:06:49', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(8, 0, 0, 1, 1, 'Metas', NULL, 'metas', 1, 1, 'metas', NULL, 16, 17, NULL, 1, 1, '2012-08-20 17:35:12', '2012-08-20 22:07:20', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(9, 0, 0, NULL, 1, 'Utilisateurs', NULL, 'utilisateurs', 1, 1, 'users', NULL, 1, 6, NULL, 9, 0, '2012-08-20 17:36:21', '2012-08-20 22:08:06', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(10, 0, 0, 9, 1, 'Groupes', NULL, 'groupes', 1, 1, 'groups', NULL, 2, 3, NULL, 9, 1, '2012-08-20 17:38:39', '2012-08-20 22:13:10', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(11, 0, 0, 9, 1, 'Utilisateurs', NULL, 'utilisateurs-1', 1, 1, 'users', NULL, 4, 5, NULL, 9, 1, '2012-08-20 17:45:26', '2012-08-20 22:17:10', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(12, 0, 0, NULL, 1, 'Apparence', NULL, 'apparence', 1, 1, 'menus', NULL, 1, 10, NULL, 12, 0, '2012-08-20 17:46:10', '2012-08-22 08:30:29', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(13, 0, 0, 12, 1, 'Menus', NULL, 'menus', 1, 1, 'menus_taxonomy', NULL, 2, 3, NULL, 12, 1, '2012-08-20 17:51:10', '2012-08-22 08:30:29', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(14, 0, 0, 12, 1, 'Blocs', NULL, 'blocs', 1, 1, 'blocs', NULL, 4, 5, 0, 12, 1, '2012-08-20 18:08:20', '2012-08-22 08:23:59', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(15, 0, 0, 12, 1, 'Variables globales', NULL, 'variables-globales', 1, 1, 'varGlobal', NULL, 6, 7, NULL, 12, 1, '2012-08-20 21:22:41', '2012-08-22 08:23:59', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(16, 0, 0, NULL, 1, 'Préférences', NULL, 'preferences', 1, 1, 'languages', NULL, 1, 6, NULL, 16, 0, '2012-08-20 21:28:21', '2012-08-20 22:27:40', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(17, 0, 0, 16, 1, 'Langues', NULL, 'langues', 1, 1, 'languages', NULL, 2, 3, NULL, 16, 1, '2012-08-20 21:29:18', '2012-08-20 22:28:38', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(18, 0, 0, 16, 1, 'Pays', NULL, 'pays', 1, 1, 'countries', NULL, 4, 5, NULL, 16, 1, '2012-08-20 21:32:18', '2012-08-20 22:29:05', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(19, 0, 0, NULL, 3, 'Consultez%%vos comptes', NULL, 'consultez-vos-comptes', 1, 1, 'http://www.google.fr/', NULL, 1, 2, NULL, 19, 0, '2012-08-22 21:16:29', '2012-08-22 21:16:55', 'a:3:{s:5:"image";N;s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(20, 0, 0, 1, 1, 'Gestion des médias', NULL, 'gestion-des-medias', 1, 1, 'medias', NULL, 6, 7, 0, 1, 1, '2012-08-23 10:03:11', '2012-08-23 10:03:11', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(21, 12, 0, NULL, 2, 'Comptes bancaires', NULL, 'comptes-bancaires', 1, 1, 'test', NULL, 1, 2, NULL, 21, 0, '2012-08-23 21:42:36', '2012-09-14 16:53:33', 'a:3:{s:5:"image";N;s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(23, 0, 0, NULL, 2, 'Prêts hypothécaires', NULL, 'prets-hypothecaires', 1, 1, 'test', NULL, 1, 24, NULL, 23, 0, '2012-08-23 21:43:39', '2012-09-16 16:31:33', 'a:3:{s:5:"image";N;s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(24, 0, 0, NULL, 2, 'Prévoyance & retraite', NULL, 'prevoyance-retraite', 1, 1, 'test', NULL, 1, 2, NULL, 24, 0, '2012-08-23 21:48:19', '2012-09-14 16:47:46', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(25, 0, 0, NULL, 2, 'Boîte à outils', NULL, 'boite-a-outils', 1, 1, 'test', NULL, 1, 2, NULL, 25, 0, '2012-08-23 21:48:48', '2012-09-11 14:16:20', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(26, 0, 0, NULL, 2, 'Qui sommes-nous ?', NULL, 'qui-sommes-nous', 1, 1, 'test', NULL, 1, 24, NULL, 26, 0, '2012-08-23 21:49:26', '2012-09-15 10:18:54', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(27, 0, 0, NULL, 2, 'Contact', NULL, 'contact', 1, 1, 'test', NULL, 1, 2, NULL, 27, 0, '2012-08-23 21:49:54', '2012-08-23 21:49:54', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(28, 0, 0, 26, 2, 'Chiffres clés', NULL, 'chiffres-cles', 1, 0, 'test', 'chiffres-cles.html', 2, 3, NULL, 26, 1, '2012-08-23 21:50:30', '2012-09-15 14:14:20', 'a:3:{s:5:"image";N;s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(29, 0, 0, 26, 2, 'Nos activités', NULL, 'nos-activites', 1, 0, 'test', 'actualites.html', 4, 7, NULL, 26, 1, '2012-08-23 21:51:14', '2012-09-15 14:13:51', 'a:3:{s:5:"image";N;s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(30, 0, 0, 29, 2, 'Nos partenariats', NULL, 'nos-partenariats', 1, 1, 'test', NULL, 5, 6, NULL, 26, 2, '2012-08-23 21:51:43', '2012-09-11 15:38:19', 'a:3:{s:5:"image";N;s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(31, 13, 0, 26, 2, 'Nos agences', NULL, 'nos-agences', 1, 0, 'test', 'agence.html', 8, 17, NULL, 26, 1, '2012-08-23 21:52:10', '2012-09-15 14:38:42', 'a:3:{s:5:"image";N;s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(32, 0, 0, 26, 2, 'Documentation', NULL, 'documentation', 1, 0, NULL, 'documentation.html', 18, 19, NULL, 26, 1, '2012-08-23 21:52:50', '2012-09-12 08:48:33', 'a:3:{s:5:"image";N;s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(33, 1, 0, 26, 2, 'Toutes les news', NULL, 'toutes-les-news', 1, 0, NULL, 'actualites.html', 20, 21, NULL, 26, 1, '2012-08-23 21:54:15', '2012-09-15 14:40:47', 'a:3:{s:5:"image";N;s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(34, 0, 0, NULL, 1, 'Formulaire', NULL, 'formulaire', 1, 1, NULL, NULL, 1, 8, NULL, 34, 0, '2012-08-31 10:42:40', '2012-08-31 10:46:42', 'a:3:{s:5:"image";N;s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(35, 0, 0, 34, 1, 'Liste des Formulaires', NULL, 'liste-des-formulaires', 1, 1, 'formulaire', NULL, 2, 3, NULL, 34, 1, '2012-08-31 10:47:20', '2012-09-05 15:31:21', 'a:3:{s:5:"image";N;s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(36, 0, 0, 34, 1, 'Type de formulaire', NULL, 'type-de-formulaire', 1, 1, 'form_taxonomy', NULL, 4, 5, NULL, 34, 1, '2012-08-31 11:01:15', '2012-08-31 11:01:15', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(37, 0, 0, 34, 1, 'Champs', NULL, 'champs-1', 1, 1, 'formfields', NULL, 6, 7, NULL, 34, 1, '2012-08-31 11:09:49', '2012-08-31 11:09:49', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(38, 0, 0, NULL, 1, 'Formulaire CRM', NULL, 'formulaire-crm', 1, 0, NULL, NULL, 1, 18, NULL, 38, 0, '2012-09-05 15:32:06', '2012-09-05 15:32:06', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(39, 0, 0, 38, 1, 'Liste des Formulaires CRM', NULL, 'liste-des-formulaires-crm', 1, 1, 'formulaireCRM', NULL, 6, 7, NULL, 38, 1, '2012-09-05 15:32:54', '2012-09-05 15:37:12', 'a:3:{s:5:"image";N;s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(40, 0, 0, 38, 1, 'Agence', NULL, 'agence', 1, 1, 'agence', NULL, 8, 9, NULL, 38, 1, '2012-09-05 15:35:50', '2012-09-05 15:36:38', 'a:3:{s:5:"image";N;s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(41, 0, 0, 38, 1, 'Caisse régionale', NULL, 'caisse-regionale', 1, 1, 'caisseRegionale', NULL, 4, 5, NULL, 38, 1, '2012-09-05 16:05:01', '2012-09-05 16:05:21', 'a:3:{s:5:"image";N;s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(42, 0, 0, 38, 1, 'Agence caisse régionale', NULL, 'agence-caisse-regionale', 1, 1, 'agenceCaisseRegionale', NULL, 10, 11, NULL, 38, 1, '2012-09-05 16:06:04', '2012-09-05 16:06:04', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(43, 0, 0, 38, 1, 'Conseiller', NULL, 'conseiller', 0, 1, 'conseiller', NULL, 12, 13, NULL, 38, 1, '2012-09-05 16:06:59', '2012-09-05 16:06:59', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(44, 0, 0, 38, 1, 'Type email', NULL, 'type-email', 1, 1, 'typeEmail', NULL, 14, 15, NULL, 38, 1, '2012-09-05 16:08:57', '2012-09-05 16:08:57', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(45, 0, 0, 38, 1, 'Type de recommandation', NULL, 'type-de-recommandation', 1, 1, 'typeRecommandation', NULL, 16, 17, NULL, 38, 1, '2012-09-05 16:11:54', '2012-09-05 16:11:54', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(46, 0, 0, 38, 1, 'Provenance de a demande', NULL, 'provenance-de-a-demande', 1, 1, 'provenanceDemande', NULL, 2, 3, NULL, 38, 1, '2012-09-05 16:13:00', '2012-09-05 16:13:58', 'a:3:{s:5:"image";N;s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(47, 0, 0, 12, 1, 'Bannière', NULL, 'banniere', 1, 1, 'banner', NULL, 8, 9, NULL, 12, 1, '2012-09-07 10:34:41', '2012-09-07 10:34:41', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(48, 25, 55, 31, 2, 'Test ss-menu', NULL, 'test-ss-menu', 1, 0, 'test', NULL, 9, 10, NULL, 26, 2, '2012-09-11 11:14:34', '2012-09-16 09:37:49', 'a:3:{s:5:"image";N;s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(53, 0, 0, 31, 2, 'Test ss-menu 2', NULL, 'test-ss-menu-2', 1, 1, 'test', NULL, 11, 12, NULL, 26, 2, '2012-09-11 11:21:41', '2012-09-12 15:35:46', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(54, 0, 0, 31, 2, 'Test ss-menu 3', NULL, 'test-ss-menu-3', 1, 1, 'test', NULL, 13, 14, NULL, 26, 2, '2012-09-11 11:22:07', '2012-09-11 11:22:07', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(55, 0, 0, 31, 2, 'Test ss-menu 4', NULL, 'test-ss-menu-4', 1, 1, 'test', NULL, 15, 16, NULL, 26, 2, '2012-09-11 14:23:23', '2012-09-11 14:23:23', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(59, 0, 0, NULL, 3, 'Ouvrez votre%%compte en ligne', NULL, 'ouvrez-votre-compte-en-ligne', 1, 1, 'test', NULL, 1, 2, NULL, 59, 0, '2012-09-12 12:13:22', '2012-09-16 11:16:19', 'a:3:{s:5:"image";N;s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(60, 0, 0, NULL, 3, 'Consultez nos%%taux hypothécaires', NULL, 'consultez-nos-taux-hypothecaires', 1, 1, 'test', NULL, 1, 2, NULL, 60, 0, '2012-09-12 12:13:59', '2012-09-12 12:13:59', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(61, 0, 0, NULL, 3, 'Simulez votre%%prêt hypothécaire', NULL, 'simulez-votre-pret-hypothecaire', 1, 1, 'test', NULL, 1, 2, NULL, 61, 0, '2012-09-12 12:14:41', '2012-09-12 12:14:41', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(63, 25, 55, 26, 2, 'Historique', NULL, 'historique', 1, 0, NULL, 'qui-sommes-nous/historique-2012.html', 22, 23, NULL, 26, 1, '2012-09-13 17:35:29', '2012-09-15 11:54:40', 'a:3:{s:5:"image";N;s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(64, 25, 0, NULL, 4, 'Qui sommes-nous ?', NULL, 'qui-sommes-nous-1', 1, 0, NULL, NULL, 1, 2, NULL, 64, 0, '2012-09-16 15:53:13', '2012-09-16 15:53:13', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(65, 0, 0, NULL, 4, 'Disclaimer', NULL, 'disclaimer', 1, 1, 'test', NULL, 1, 2, NULL, 65, 0, '2012-09-16 15:53:49', '2012-09-16 15:53:49', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(66, 0, 0, NULL, 4, 'Partenaires', NULL, 'partenaires', 1, 1, 'test', NULL, 1, 2, NULL, 66, 0, '2012-09-16 15:54:08', '2012-09-16 15:54:08', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(67, 0, 0, NULL, 4, 'Sitemap', NULL, 'sitemap', 1, 1, 'test', NULL, 1, 2, NULL, 67, 0, '2012-09-16 15:54:28', '2012-09-16 15:54:28', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(68, 0, 0, 23, 2, 'Taux de crédit', NULL, 'taux-de-credit', 1, 1, 'test', NULL, 2, 3, NULL, 23, 1, '2012-09-16 16:32:30', '2012-09-16 16:32:30', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(69, 0, 0, 23, 2, 'Rachat d''hypothèque', NULL, 'rachat-d-hypotheque', 1, 1, 'test', NULL, 4, 5, NULL, 23, 1, '2012-09-16 16:35:23', '2012-09-16 16:35:23', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(70, 0, 0, 71, 2, 'Votre capacité d''emprunt', NULL, 'votre-capacite-d-emprunt', 1, 1, 'test', NULL, 7, 8, NULL, 23, 2, '2012-09-16 16:37:19', '2012-09-17 09:17:03', 'a:3:{s:5:"image";s:31:"uploads/menu//5056ce6f72f31.png";s:3:"alt";s:12:"calculatrice";s:5:"title";s:12:"calculatrice";}', '5056ce6f72f31.png', 1),
(71, 0, 0, 23, 2, 'Nos offres de crédit', NULL, 'nos-offres-de-credit', 1, 1, 'test', NULL, 6, 19, 0, 23, 1, '2012-09-16 16:51:37', '2012-09-16 16:51:37', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(72, 0, 0, 71, 2, 'CA Ecoprêt', NULL, 'ca-ecopret', 1, 1, 'test', NULL, 9, 10, NULL, 23, 2, '2012-09-16 16:52:34', '2012-09-16 16:52:34', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(73, 0, 0, 71, 2, 'CA 2 en 1', NULL, 'ca-2-en-1', 1, 1, 'test', NULL, 11, 12, NULL, 23, 2, '2012-09-16 17:01:01', '2012-09-16 17:01:01', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(74, 0, 0, 71, 2, 'CA Seren''Immo', NULL, 'ca-seren-immo', 1, 1, 'test', NULL, 13, 14, NULL, 23, 2, '2012-09-16 17:01:50', '2012-09-16 17:02:04', 'a:3:{s:5:"image";N;s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(75, 0, 0, 71, 2, 'CA Jeunes actifs', NULL, 'ca-jeunes-actifs', 1, 1, 'test', NULL, 15, 16, NULL, 23, 2, '2012-09-16 17:02:56', '2012-09-16 17:02:56', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(76, 0, 0, 23, 2, 'Comparatifs de nos offres', NULL, 'comparatifs-de-nos-offres', 1, 1, 'test', NULL, 20, 21, NULL, 23, 1, '2012-09-16 17:03:40', '2012-09-16 17:03:40', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(77, 0, 0, 23, 2, 'Nos guides pratiques', NULL, 'nos-guides-pratiques', 1, 1, 'test', NULL, 22, 23, NULL, 23, 1, '2012-09-16 17:04:11', '2012-09-16 17:04:11', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0),
(78, 0, 0, 71, 2, 'CA Travaux', NULL, 'ca-travaux', 1, 1, 'test', NULL, 17, 18, NULL, 23, 2, '2012-09-16 17:04:46', '2012-09-16 17:04:46', 'a:3:{s:5:"image";s:0:"";s:3:"alt";N;s:5:"title";N;}', NULL, 0);

-- --------------------------------------------------------

--
-- Structure de la table `menu_translations_ext`
--

CREATE TABLE IF NOT EXISTS `menu_translations_ext` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `object_id` int(11) DEFAULT NULL,
  `locale` varchar(255) NOT NULL,
  `field` varchar(255) NOT NULL,
  `content` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lookup_unique_idx` (`locale`,`object_id`,`field`),
  KEY `IDX_59941099232D562B` (`object_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=73 ;

--
-- Contenu de la table `menu_translations_ext`
--

INSERT INTO `menu_translations_ext` (`id`, `object_id`, `locale`, `field`, `content`) VALUES
(9, 23, 'en_us', 'title', 'Savings'),
(10, 23, 'en_us', 'slug', 'epargne'),
(11, 23, 'en_us', 'published', '1'),
(12, 23, 'en_us', 'link_taxonomy', '1'),
(13, 23, 'en_us', 'urls', 'test'),
(14, 23, 'en_us', 'media', 'a:3:{s:5:"image";N;s:3:"alt";N;s:5:"title";N;}'),
(17, 24, 'en_us', 'title', 'Savings & Retirement'),
(18, 24, 'en_us', 'slug', 'prevoyance-retraite'),
(19, 24, 'en_us', 'published', '1'),
(20, 24, 'en_us', 'link_taxonomy', '1'),
(21, 24, 'en_us', 'urls', 'test'),
(22, 24, 'en_us', 'media', 'a:3:{s:5:"image";N;s:3:"alt";N;s:5:"title";N;}'),
(29, 21, 'en_us', 'title', 'Account'),
(30, 21, 'en_us', 'slug', 'comptes-bancaires'),
(31, 21, 'en_us', 'published', '1'),
(32, 21, 'en_us', 'link_taxonomy', '1'),
(33, 21, 'en_us', 'urls', 'test'),
(34, 21, 'en_us', 'media', 'a:3:{s:5:"image";N;s:3:"alt";N;s:5:"title";N;}'),
(41, 26, 'en_us', 'title', 'About us'),
(42, 26, 'en_us', 'slug', 'qui-sommes-nous'),
(43, 26, 'en_us', 'published', '1'),
(44, 26, 'en_us', 'media', 'a:3:{s:5:"image";N;s:3:"alt";N;s:5:"title";N;}'),
(45, 33, 'en_us', 'title', 'All the news'),
(46, 33, 'en_us', 'slug', 'toutes-les-news'),
(47, 33, 'en_us', 'published', '1'),
(48, 33, 'en_us', 'urls_content', 'news.html'),
(49, 33, 'en_us', 'category', '2'),
(50, 33, 'en_us', 'media', 'a:3:{s:5:"image";N;s:3:"alt";N;s:5:"title";N;}'),
(51, 63, 'en_us', 'title', 'History'),
(52, 63, 'en_us', 'slug', 'historique'),
(53, 63, 'en_us', 'published', '1'),
(54, 63, 'en_us', 'urls_content', 'qui-sommes-nous/historique-2012.html'),
(55, 63, 'en_us', 'content', '56'),
(56, 63, 'en_us', 'media', 'a:3:{s:5:"image";N;s:3:"alt";N;s:5:"title";N;}'),
(57, 48, 'en_us', 'title', 'Test ss-menu en'),
(58, 48, 'en_us', 'slug', 'test-ss-menu'),
(59, 48, 'en_us', 'published', '1'),
(60, 48, 'en_us', 'urls_content', 'home/story.html'),
(61, 48, 'en_us', 'category', '20'),
(62, 48, 'en_us', 'content', '56'),
(63, 48, 'en_us', 'media', 'a:3:{s:5:"image";N;s:3:"alt";N;s:5:"title";N;}'),
(67, 31, 'en_us', 'title', 'Our agencies'),
(68, 31, 'en_us', 'slug', 'our-agencies'),
(69, 31, 'en_us', 'published', '1'),
(70, 31, 'en_us', 'urls_content', 'agency.html'),
(71, 31, 'en_us', 'category', '14'),
(72, 31, 'en_us', 'media', 'a:3:{s:5:"image";N;s:3:"alt";N;s:5:"title";N;}');

-- --------------------------------------------------------

--
-- Structure de la table `metas`
--

CREATE TABLE IF NOT EXISTS `metas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `balise` varchar(150) NOT NULL,
  `type` varchar(50) NOT NULL,
  `display` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Contenu de la table `metas`
--

INSERT INTO `metas` (`id`, `name`, `balise`, `type`, `display`) VALUES
(1, 'Title', '<title>#1</title>', 'normal', 'text'),
(2, 'Description', '<meta name="description" content="#1" />', 'normal', 'textarea'),
(3, 'Keywords', '<meta name="keywords" content="#1" />', 'normal', 'textarea'),
(4, 'Open Graph Title', '<meta property="og:title" content="#1" />', 'og', 'text'),
(5, 'Open Graph Image', '<meta property="og:image" content="#1" />', 'og', 'text'),
(6, 'Open Graph Description', '<meta property="og:description" content="#1" />', 'og', 'textarea'),
(7, 'Content-type', '<meta http-equiv="Content-Type" content="#1" />', 'normal', 'text'),
(8, 'Content-Language', '<meta http-equiv="Content-Language" content="#1" />', 'normal', 'text'),
(9, 'Robots', '<meta name="robots" content="#1" />', 'normal', 'text'),
(10, 'Canonical', '<link rel="canonical" href="#1" />', 'normal', 'text'),
(11, 'Url', 'text', 'other', 'text');

-- --------------------------------------------------------

--
-- Structure de la table `metasvalue`
--

CREATE TABLE IF NOT EXISTS `metasvalue` (
  `meta_id` int(11) NOT NULL,
  `content_translation_id` int(11) NOT NULL,
  `value` longtext,
  PRIMARY KEY (`meta_id`,`content_translation_id`),
  KEY `IDX_825F2B2039FCA6F9` (`meta_id`),
  KEY `IDX_825F2B20F641D1F1` (`content_translation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `metasvalue`
--

INSERT INTO `metasvalue` (`meta_id`, `content_translation_id`, `value`) VALUES
(1, 28, 'Guide des tarifs 2012'),
(1, 29, ''),
(1, 30, ''),
(1, 31, 'Guide des offres'),
(1, 32, 'Offers'' guide'),
(1, 33, 'Offers'' guide'),
(1, 34, 'Nouvelle plateforme e-banking'),
(1, 35, 'Nouvelle plateforme e-banking'),
(1, 36, 'Nouvelle plateforme e-banking'),
(1, 37, 'Réinventons un banque simple'),
(1, 38, 'Home'),
(1, 39, 'Home'),
(1, 40, 'Offre exceptionnelle'),
(1, 41, 'test 5'),
(1, 42, 'teq'),
(1, 46, 'Test agence'),
(1, 47, 'Test agency'),
(1, 48, 'Test agentur'),
(1, 49, 'Chiffres clés'),
(1, 50, 'Key figures'),
(1, 51, 'Key figures'),
(1, 52, 'Agence Genève Cornavin'),
(1, 53, 'Agency Geneva Cornavin'),
(1, 54, 'Genf Cornavin'),
(1, 55, 'Historique de Crédit Agricole Financempents'),
(1, 56, 'Story'),
(1, 57, 'Geschichte'),
(1, 58, 'Nouvelle exposition'),
(1, 59, 'New exposition'),
(1, 60, 'New exposition'),
(2, 28, 'At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est.'),
(2, 29, ''),
(2, 30, ''),
(2, 31, ''),
(2, 32, ''),
(2, 33, ''),
(2, 34, 'Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis.'),
(2, 35, ''),
(2, 36, ''),
(2, 37, ''),
(2, 38, ''),
(2, 39, ''),
(2, 40, ''),
(2, 41, ''),
(2, 42, ''),
(2, 46, ''),
(2, 47, ''),
(2, 48, ''),
(2, 49, ''),
(2, 50, ''),
(2, 51, ''),
(2, 52, ''),
(2, 53, ''),
(2, 54, ''),
(2, 55, 'Crédit Agricole Financements (Suisse) SA met ce savoir-faire à votre service'),
(2, 56, ''),
(2, 57, ''),
(2, 58, ''),
(2, 59, ''),
(2, 60, ''),
(3, 28, ''),
(3, 29, ''),
(3, 30, ''),
(3, 31, ''),
(3, 32, ''),
(3, 33, ''),
(3, 34, ''),
(3, 35, ''),
(3, 36, ''),
(3, 37, ''),
(3, 38, ''),
(3, 39, ''),
(3, 40, ''),
(3, 41, ''),
(3, 42, ''),
(3, 46, ''),
(3, 47, ''),
(3, 48, ''),
(3, 49, ''),
(3, 50, ''),
(3, 51, ''),
(3, 52, ''),
(3, 53, ''),
(3, 54, ''),
(3, 55, ''),
(3, 56, ''),
(3, 57, ''),
(3, 58, ''),
(3, 59, ''),
(3, 60, ''),
(7, 28, 'text/html; charset=utf-8'),
(7, 29, 'text/html; charset=utf-8'),
(7, 30, 'text/html; charset=utf-8'),
(7, 31, 'text/html; charset=utf-8'),
(7, 32, 'text/html; charset=utf-8'),
(7, 33, 'text/html; charset=utf-8'),
(7, 34, 'text/html; charset=utf-8'),
(7, 35, 'text/html; charset=utf-8'),
(7, 36, 'text/html; charset=utf-8'),
(7, 37, 'text/html; charset=utf-8'),
(7, 38, 'text/html; charset=utf-8'),
(7, 39, 'text/html; charset=utf-8'),
(7, 40, 'text/html; charset=utf-8'),
(7, 41, 'text/html; charset=utf-8'),
(7, 42, 'text/html; charset=utf-8'),
(7, 46, 'text/html; charset=utf-8'),
(7, 47, 'text/html; charset=utf-8'),
(7, 48, 'text/html; charset=utf-8'),
(7, 49, 'text/html; charset=utf-8'),
(7, 50, 'text/html; charset=utf-8'),
(7, 51, 'text/html; charset=utf-8'),
(7, 52, 'text/html; charset=utf-8'),
(7, 53, 'text/html; charset=utf-8'),
(7, 54, 'text/html; charset=utf-8'),
(7, 55, 'text/html; charset=utf-8'),
(7, 56, 'text/html; charset=utf-8'),
(7, 57, 'text/html; charset=utf-8'),
(7, 58, 'text/html; charset=utf-8'),
(7, 59, 'text/html; charset=utf-8'),
(7, 60, 'text/html; charset=utf-8'),
(8, 28, 'fr'),
(8, 29, 'en'),
(8, 30, 'de'),
(8, 31, 'fr'),
(8, 32, 'en'),
(8, 33, 'de'),
(8, 34, 'fr'),
(8, 35, 'en'),
(8, 36, 'de'),
(8, 37, 'fr'),
(8, 38, 'en'),
(8, 39, 'de'),
(8, 40, 'fr'),
(8, 41, 'en'),
(8, 42, 'de'),
(8, 46, 'fr'),
(8, 47, 'en'),
(8, 48, 'de'),
(8, 49, 'fr'),
(8, 50, 'en'),
(8, 51, 'de'),
(8, 52, 'fr'),
(8, 53, 'en'),
(8, 54, 'de'),
(8, 55, 'fr'),
(8, 56, 'en'),
(8, 57, 'de'),
(8, 58, 'fr'),
(8, 59, 'en'),
(8, 60, 'de'),
(9, 28, 'index,follow'),
(9, 29, 'index,follow'),
(9, 30, 'index,follow'),
(9, 31, 'index,follow'),
(9, 32, 'index,follow'),
(9, 33, 'index,follow'),
(9, 34, 'index,follow'),
(9, 35, 'index,follow'),
(9, 36, 'index,follow'),
(9, 37, 'index,follow'),
(9, 38, 'index,follow'),
(9, 39, 'index,follow'),
(9, 40, 'index,follow'),
(9, 41, 'index,follow'),
(9, 42, 'index,follow'),
(9, 46, 'index,follow'),
(9, 47, 'index,follow'),
(9, 48, 'index,follow'),
(9, 49, 'index,follow'),
(9, 50, 'index,follow'),
(9, 51, 'index,follow'),
(9, 52, 'index,follow'),
(9, 53, 'index,follow'),
(9, 54, 'index,follow'),
(9, 55, 'index,follow'),
(9, 56, 'index,follow'),
(9, 57, 'index,follow'),
(9, 58, 'index,follow'),
(9, 59, 'index,follow'),
(9, 60, 'index,follow'),
(10, 28, 'guide-des-tarifs-2012'),
(10, 29, 'prices-guide-2012'),
(10, 30, 'prices'),
(10, 31, 'guide-des-offres'),
(10, 32, 'offers-guide'),
(10, 33, 'offers-guide-1'),
(10, 34, 'nouvelle-plateforme-e-banking'),
(10, 35, 'nouvelle-plateforme-e-banking-1'),
(10, 36, 'nouvelle-plateforme-e-banking-2'),
(10, 37, 'accueil.html'),
(10, 38, 'home'),
(10, 39, 'home-1'),
(10, 40, 'offre-exceptionnelle'),
(10, 41, 'test'),
(10, 42, 'teq'),
(10, 46, 'test-agence-fr'),
(10, 47, 'test-agency'),
(10, 48, 'test-agentur'),
(10, 49, 'chiffres-cles'),
(10, 50, 'key-figures'),
(10, 51, 'key-figures-1'),
(10, 52, 'agence-geneve-cornavin'),
(10, 53, 'agency-geneva-cornavin'),
(10, 54, 'genf-cornavin'),
(10, 55, 'historique'),
(10, 56, 'story'),
(10, 57, 'geschichte'),
(10, 58, 'nouvelle-exposition'),
(10, 59, 'new-exposition'),
(10, 60, 'new-exposition-1'),
(11, 28, ''),
(11, 29, ''),
(11, 30, ''),
(11, 31, ''),
(11, 32, ''),
(11, 33, ''),
(11, 34, 'actualites/nouvelle-plateforme-e-banking.html'),
(11, 35, ''),
(11, 36, ''),
(11, 37, 'accueil.html'),
(11, 38, ''),
(11, 39, ''),
(11, 40, 'actualites-2012/offre-exceptionnelle.html'),
(11, 41, 'test.html'),
(11, 42, ''),
(11, 46, 'agences/test-agence.html'),
(11, 47, ''),
(11, 48, ''),
(11, 49, 'chiffres-cles.html'),
(11, 50, ''),
(11, 51, ''),
(11, 52, ''),
(11, 53, ''),
(11, 54, ''),
(11, 55, 'qui-sommes-nous/historique-2012.html'),
(11, 56, ''),
(11, 57, ''),
(11, 58, ''),
(11, 59, ''),
(11, 60, '');

-- --------------------------------------------------------

--
-- Structure de la table `metasvaluecategory`
--

CREATE TABLE IF NOT EXISTS `metasvaluecategory` (
  `meta_id` int(11) NOT NULL,
  `category_translation_id` int(11) NOT NULL,
  `value` longtext,
  PRIMARY KEY (`meta_id`,`category_translation_id`),
  KEY `IDX_47E4F2139FCA6F9` (`meta_id`),
  KEY `IDX_47E4F217DBA6818` (`category_translation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `metasvaluecategory`
--

INSERT INTO `metasvaluecategory` (`meta_id`, `category_translation_id`, `value`) VALUES
(1, 1, 's:11:"Actualités";'),
(1, 2, 's:4:"News";'),
(1, 3, 's:5:"Nueue";'),
(1, 10, 's:13:"Documentation";'),
(1, 11, 's:9:"Documents";'),
(1, 12, 's:4:"Docs";'),
(1, 13, 's:6:"Agence";'),
(1, 14, 's:6:"Agency";'),
(1, 15, 's:7:"Agentur";'),
(1, 16, 's:16:"Actualités 2012";'),
(1, 17, 's:0:"";'),
(1, 18, 's:0:"";'),
(1, 19, 's:10:"Générale";'),
(1, 20, 's:0:"";'),
(1, 21, 's:0:"";'),
(1, 22, 's:7:"Accueil";'),
(1, 23, 's:4:"Home";'),
(1, 24, 's:10:"Startseite";'),
(1, 25, 's:46:"La balise Titre Crédit agricoles financements";'),
(1, 26, 's:6:"Who is";'),
(1, 27, 's:8:"Uber uns";'),
(2, 1, 's:0:"";'),
(2, 2, 's:0:"";'),
(2, 3, 's:0:"";'),
(2, 10, 's:0:"";'),
(2, 11, 's:0:"";'),
(2, 12, 's:0:"";'),
(2, 13, 's:0:"";'),
(2, 14, 's:0:"";'),
(2, 15, 's:0:"";'),
(2, 16, 's:65:"Retrouvez toutes les actualités de l''année 2012 en un seul clic";'),
(2, 17, 's:0:"";'),
(2, 18, 's:0:"";'),
(2, 19, 's:0:"";'),
(2, 20, 's:0:"";'),
(2, 21, 's:0:"";'),
(2, 22, 's:7:"Accueil";'),
(2, 23, 's:4:"Home";'),
(2, 24, 's:10:"Startseite";'),
(2, 25, 's:83:"La meta Description de la catégorie Qui-sommes-nous Crédit agricoles financements";'),
(2, 26, 's:0:"";'),
(2, 27, 's:0:"";'),
(3, 1, 's:0:"";'),
(3, 2, 's:0:"";'),
(3, 3, 's:0:"";'),
(3, 10, 's:0:"";'),
(3, 11, 's:0:"";'),
(3, 12, 's:0:"";'),
(3, 13, 's:0:"";'),
(3, 14, 's:0:"";'),
(3, 15, 's:0:"";'),
(3, 16, 's:0:"";'),
(3, 17, 's:0:"";'),
(3, 18, 's:0:"";'),
(3, 19, 's:0:"";'),
(3, 20, 's:0:"";'),
(3, 21, 's:0:"";'),
(3, 22, 's:7:"Accueil";'),
(3, 23, 's:4:"Home";'),
(3, 24, 's:10:"Startseite";'),
(3, 25, 's:0:"";'),
(3, 26, 's:0:"";'),
(3, 27, 's:0:"";'),
(7, 1, 's:24:"text/html; charset=utf-8";'),
(7, 2, 's:24:"text/html; charset=utf-8";'),
(7, 3, 's:24:"text/html; charset=utf-8";'),
(7, 10, 's:24:"text/html; charset=utf-8";'),
(7, 11, 's:24:"text/html; charset=utf-8";'),
(7, 12, 's:24:"text/html; charset=utf-8";'),
(7, 13, 's:24:"text/html; charset=utf-8";'),
(7, 14, 's:24:"text/html; charset=utf-8";'),
(7, 15, 's:24:"text/html; charset=utf-8";'),
(7, 16, 's:24:"text/html; charset=utf-8";'),
(7, 17, 's:24:"text/html; charset=utf-8";'),
(7, 18, 's:24:"text/html; charset=utf-8";'),
(7, 19, 's:24:"text/html; charset=utf-8";'),
(7, 20, 's:24:"text/html; charset=utf-8";'),
(7, 21, 's:24:"text/html; charset=utf-8";'),
(7, 22, 's:24:"text/html; charset=utf-8";'),
(7, 23, 's:24:"text/html; charset=utf-8";'),
(7, 24, 's:24:"text/html; charset=utf-8";'),
(7, 25, 's:24:"text/html; charset=utf-8";'),
(7, 26, 's:24:"text/html; charset=utf-8";'),
(7, 27, 's:24:"text/html; charset=utf-8";'),
(8, 1, 's:2:"fr";'),
(8, 2, 's:2:"en";'),
(8, 3, 's:2:"de";'),
(8, 10, 's:2:"fr";'),
(8, 11, 's:2:"en";'),
(8, 12, 's:2:"de";'),
(8, 13, 's:2:"fr";'),
(8, 14, 's:2:"en";'),
(8, 15, 's:2:"de";'),
(8, 16, 's:2:"fr";'),
(8, 17, 's:2:"en";'),
(8, 18, 's:2:"de";'),
(8, 19, 's:2:"fr";'),
(8, 20, 's:2:"en";'),
(8, 21, 's:2:"de";'),
(8, 22, 's:2:"fr";'),
(8, 23, 's:2:"en";'),
(8, 24, 's:2:"de";'),
(8, 25, 's:2:"fr";'),
(8, 26, 's:2:"en";'),
(8, 27, 's:2:"de";'),
(9, 1, 's:12:"index,follow";'),
(9, 2, 's:12:"index,follow";'),
(9, 3, 's:12:"index,follow";'),
(9, 10, 's:12:"index,follow";'),
(9, 11, 's:12:"index,follow";'),
(9, 12, 's:12:"index,follow";'),
(9, 13, 's:12:"index,follow";'),
(9, 14, 's:12:"index,follow";'),
(9, 15, 's:12:"index,follow";'),
(9, 16, 's:12:"index,follow";'),
(9, 17, 's:12:"index,follow";'),
(9, 18, 's:12:"index,follow";'),
(9, 19, 's:12:"index,follow";'),
(9, 20, 's:12:"index,follow";'),
(9, 21, 's:12:"index,follow";'),
(9, 22, 's:12:"index,follow";'),
(9, 23, 's:12:"index,follow";'),
(9, 24, 's:12:"index,follow";'),
(9, 25, 's:12:"index,follow";'),
(9, 26, 's:12:"index,follow";'),
(9, 27, 's:12:"index,follow";'),
(10, 1, 's:10:"actualites";'),
(10, 2, 's:4:"news";'),
(10, 3, 's:5:"nueue";'),
(10, 10, 's:9:"documents";'),
(10, 11, 's:11:"documents-1";'),
(10, 12, 's:4:"docs";'),
(10, 13, 's:6:"agence";'),
(10, 14, 's:6:"agency";'),
(10, 15, 's:7:"agentur";'),
(10, 16, 's:15:"actualites-2012";'),
(10, 17, 's:9:"news-2012";'),
(10, 18, 's:10:"nueue-2012";'),
(10, 19, 's:0:"";'),
(10, 20, 's:0:"";'),
(10, 21, 's:0:"";'),
(10, 22, 's:0:"";'),
(10, 23, 's:0:"";'),
(10, 24, 's:0:"";'),
(10, 25, 's:0:"";'),
(10, 26, 's:0:"";'),
(10, 27, 's:0:"";'),
(11, 1, 's:15:"actualites.html";'),
(11, 2, 's:0:"";'),
(11, 3, 's:0:"";'),
(11, 13, 's:0:"";'),
(11, 14, 's:0:"";'),
(11, 15, 's:0:"";'),
(11, 16, 's:20:"actualites-2012.html";'),
(11, 17, 's:0:"";'),
(11, 18, 's:0:"";'),
(11, 19, 's:0:"";'),
(11, 20, 's:0:"";'),
(11, 21, 's:0:"";'),
(11, 22, 's:0:"";'),
(11, 23, 's:0:"";'),
(11, 24, 's:0:"";'),
(11, 25, 's:0:"";'),
(11, 26, 's:0:"";'),
(11, 27, 's:0:"";');

-- --------------------------------------------------------

--
-- Structure de la table `provenancedemande`
--

CREATE TABLE IF NOT EXISTS `provenancedemande` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(255) NOT NULL,
  `published` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Contenu de la table `provenancedemande`
--

INSERT INTO `provenancedemande` (`id`, `libelle`, `published`) VALUES
(1, 'Corporate', 1),
(2, 'CAS', 1),
(3, 'Spontanée', 1),
(4, 'Caisse régionale', 1);

-- --------------------------------------------------------

--
-- Structure de la table `redirect`
--

CREATE TABLE IF NOT EXISTS `redirect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `source` varchar(255) NOT NULL,
  `destination` varchar(255) NOT NULL,
  `status_code` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `last_accessed` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `select`
--

CREATE TABLE IF NOT EXISTS `select` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(255) NOT NULL,
  `content` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `statutdemande`
--

CREATE TABLE IF NOT EXISTS `statutdemande` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(255) NOT NULL,
  `published` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Contenu de la table `statutdemande`
--

INSERT INTO `statutdemande` (`id`, `libelle`, `published`) VALUES
(1, 'statut n°1', 1),
(2, 'statut n°2', 1),
(3, 'Statut n°3', 1),
(5, 'statut non publié', 0);

-- --------------------------------------------------------

--
-- Structure de la table `typeemail`
--

CREATE TABLE IF NOT EXISTS `typeemail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `message` longtext NOT NULL,
  `published` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Contenu de la table `typeemail`
--

INSERT INTO `typeemail` (`id`, `type`, `message`, `published`) VALUES
(1, 'Projet nom réalisable', '<p>\r\n	Ce texte a pour avantage d&#39;utiliser des mots de longueur variable, essayant de simuler une occupation normale. La m&eacute;thode simpliste consistant &agrave; copier-coller un court texte plusieurs fois (&laquo;&nbsp;ceci est un faux-texte ceci est un faux-texte ceci est un faux-texte ceci est un faux-texte ceci est un faux-texte&nbsp;&raquo;) a l&#39;inconv&eacute;nient de ne pas permettre une juste appr&eacute;ciation typographique du r&eacute;sultat final.</p>', 1),
(2, 'Capacité de financement', '<p>\r\n	<span class="lang-la" lang="la"><i>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed non risus. Suspendisse lectus tortor, dignissim sit amet, adipiscing nec, ultricies sed, dolor. Cras elementum ultrices diam. Maecenas ligula massa, varius a, semper congue, euismod non, mi. Proin porttitor, orci nec nonummy molestie, enim est eleifend mi, non fermentum diam nisl sit amet erat. Duis semper. Duis arcu massa, scelerisque vitae, consequat in, pretium a, enim. Pellentesque congue. Ut in risus volutpat libero pharetra tempor. </i></span></p>', 1),
(3, 'Email relance', '<p>\r\n	Dans le domaine informatique, l&#39;&eacute;diteur de mise en page <a href="http://fr.wikipedia.org/wiki/QuarkXPress" title="QuarkXPress">QuarkXPress</a> propose une Xtension baptis&eacute;e &laquo;&nbsp;Jabber&nbsp;&raquo; et qui permet la g&eacute;n&eacute;ration de faux-texte calibr&eacute; en latin, en anglais ou en fran&ccedil;ais (les bases &eacute;tant modifiables). <a href="http://fr.wikipedia.org/wiki/Adobe_InDesign" title="Adobe InDesign">Adobe InDesign</a> et <a href="http://fr.wikipedia.org/wiki/Scribus" title="Scribus">Scribus</a> (l&#39;&eacute;quivalent libre et open source) en contiennent un en natif. Il existe &eacute;galement une extension d&#39;<a class="mw-redirect" href="http://fr.wikipedia.org/wiki/OpenOffice" title="OpenOffice">OpenOffice</a> (<i>Lorem ipsum generator</i>) qui a cette fonction. De m&ecirc;me, l&#39;extension <a class="external text" href="http://www.ctan.org/pkg/lipsum" rel="nofollow">lipsum</a> du syst&egrave;me de composition de documents <a href="http://fr.wikipedia.org/wiki/LaTeX" title="LaTeX">LaTeX</a> offre cette fonctionnalit&eacute;.</p>', 1);

-- --------------------------------------------------------

--
-- Structure de la table `typerecommandation`
--

CREATE TABLE IF NOT EXISTS `typerecommandation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(255) NOT NULL,
  `published` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Contenu de la table `typerecommandation`
--

INSERT INTO `typerecommandation` (`id`, `libelle`, `published`) VALUES
(1, 'Reco Synergie', 1),
(2, 'Reco WEB', 1),
(3, 'Reco téléphone', 1);

-- --------------------------------------------------------

--
-- Structure de la table `urls_content`
--

CREATE TABLE IF NOT EXISTS `urls_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content_id` int(11) DEFAULT NULL,
  `url` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_8C28CEEA84A0A3ED` (`content_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=101 ;

--
-- Contenu de la table `urls_content`
--

INSERT INTO `urls_content` (`id`, `content_id`, `url`) VALUES
(53, 28, 'documentation/guide-des-tarifs-2012.html'),
(54, 29, 'documents-1/prices-guide-2012.html'),
(55, 30, 'docs/prices.html'),
(56, 31, 'documentation/guide-des-offres.html'),
(57, 32, 'documents-1/offers-guide.html'),
(58, 33, 'docs/offers-guide-1.html'),
(59, 34, 'actualites/nouvelle-plateforme-e-banking.html'),
(60, 35, 'news/nouvelle-plateforme-e-banking-1.html'),
(61, 36, 'nueue/nouvelle-plateforme-e-banking-2.html'),
(62, 37, 'accueil.html'),
(63, 38, 'general/home.html'),
(64, 39, 'general-1/home-1.html'),
(65, 40, 'actualites-2012/offre-exceptionnelle.html'),
(66, 41, 'test.html'),
(67, 42, 'nueue/teq.html'),
(70, 48, 'agentur/test-agentur.html'),
(72, 47, 'agency/test-agency.html'),
(74, 46, 'agences/test-agence.html'),
(89, 49, 'chiffres-cles.html'),
(90, 50, 'general/key-figures.html'),
(91, 51, 'general-1/key-figures-1.html'),
(92, 52, 'agence/agence-geneve-cornavin.html'),
(93, 53, 'agency/agency-geneva-cornavin.html'),
(94, 54, 'agentur/genf-cornavin.html'),
(95, 55, 'qui-sommes-nous/historique-2012.html'),
(96, 56, 'home/story.html'),
(97, 57, 'startseite/geschichte.html'),
(98, 58, 'actualites.htmlnouvelle-exposition.html'),
(99, 59, 'news/new-exposition.html'),
(100, 60, 'nueue/new-exposition-1.html');

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `salt` varchar(32) NOT NULL,
  `password` varchar(40) NOT NULL,
  `email` varchar(60) NOT NULL,
  `language` varchar(255) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_8D93D649E7927C74` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Contenu de la table `user`
--

INSERT INTO `user` (`id`, `username`, `firstname`, `lastname`, `salt`, `password`, `email`, `language`, `is_active`) VALUES
(2, 'abdoul', 'Abdel', 'Haffaf', 'd73344caff680aec5bfe414a72858b83', 'dc61aad7d655555bcbf5ecc6530f7bf0c57c1713', 'ahaffaf@3c-e.com', 'en', 1),
(4, 'admin', 'Damien', 'Corona', '7e7f9e56f69233a1895fc38009057abf', 'ed66e40706666f40bb58550228c5042ff8f26099', 'dcorona@3c-e.com', 'fr', 1),
(5, 'MESSINA', 'Florian', 'flo', 'd67848f950e5a52934b7a88a54b264d6', '5f53d82a690fded9ff67b3d20f905105bcd42ddc', 'fmessina@3c-e.com', 'fr', 1);

-- --------------------------------------------------------

--
-- Structure de la table `user_group`
--

CREATE TABLE IF NOT EXISTS `user_group` (
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`user_id`,`group_id`),
  KEY `IDX_8F02BF9DA76ED395` (`user_id`),
  KEY `IDX_8F02BF9DFE54D947` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `user_group`
--

INSERT INTO `user_group` (`user_id`, `group_id`) VALUES
(2, 1),
(4, 1),
(5, 1);

-- --------------------------------------------------------

--
-- Structure de la table `varglobal`
--

CREATE TABLE IF NOT EXISTS `varglobal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(255) NOT NULL,
  `tag` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `published` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `agencecaisseregionale`
--
ALTER TABLE `agencecaisseregionale`
  ADD CONSTRAINT `FK_29B7C9F5882C8A0F` FOREIGN KEY (`caisseRegional_id`) REFERENCES `caisseregionale` (`id`);

--
-- Contraintes pour la table `blocactu`
--
ALTER TABLE `blocactu`
  ADD CONSTRAINT `FK_67B9FF1A12469DE2` FOREIGN KEY (`category_id`) REFERENCES `categories_ext` (`id`),
  ADD CONSTRAINT `FK_67B9FF1A5582E9C0` FOREIGN KEY (`bloc_id`) REFERENCES `bloc` (`id`);

--
-- Contraintes pour la table `blocbanner`
--
ALTER TABLE `blocbanner`
  ADD CONSTRAINT `FK_E10533A05582E9C0` FOREIGN KEY (`bloc_id`) REFERENCES `bloc` (`id`);

--
-- Contraintes pour la table `blocbannerright`
--
ALTER TABLE `blocbannerright`
  ADD CONSTRAINT `FK_67DDBD8B5582E9C0` FOREIGN KEY (`bloc_id`) REFERENCES `bloc` (`id`);

--
-- Contraintes pour la table `blocbannerright_banner`
--
ALTER TABLE `blocbannerright_banner`
  ADD CONSTRAINT `FK_6D7F9595684EC833` FOREIGN KEY (`banner_id`) REFERENCES `banner` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_6D7F959522284FAA` FOREIGN KEY (`blocbannerright_id`) REFERENCES `blocbannerright` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `blocbannerslide`
--
ALTER TABLE `blocbannerslide`
  ADD CONSTRAINT `FK_A1F826FD5582E9C0` FOREIGN KEY (`bloc_id`) REFERENCES `bloc` (`id`);

--
-- Contraintes pour la table `blochtml`
--
ALTER TABLE `blochtml`
  ADD CONSTRAINT `FK_FCB304BD5582E9C0` FOREIGN KEY (`bloc_id`) REFERENCES `bloc` (`id`);

--
-- Contraintes pour la table `blocmenu`
--
ALTER TABLE `blocmenu`
  ADD CONSTRAINT `FK_99CFC6CB5582E9C0` FOREIGN KEY (`bloc_id`) REFERENCES `bloc` (`id`),
  ADD CONSTRAINT `FK_99CFC6CBCCD7E912` FOREIGN KEY (`menu_id`) REFERENCES `menutaxonomy` (`id`);

--
-- Contraintes pour la table `blocmenuleft`
--
ALTER TABLE `blocmenuleft`
  ADD CONSTRAINT `FK_2B8A2BC25582E9C0` FOREIGN KEY (`bloc_id`) REFERENCES `bloc` (`id`),
  ADD CONSTRAINT `FK_2B8A2BC2CCD7E912` FOREIGN KEY (`menu_id`) REFERENCES `menu_ext` (`id`);

--
-- Contraintes pour la table `bloc_category_de`
--
ALTER TABLE `bloc_category_de`
  ADD CONSTRAINT `FK_C96625512D214E40` FOREIGN KEY (`categorytranslation_id`) REFERENCES `category_translation` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_C96625515582E9C0` FOREIGN KEY (`bloc_id`) REFERENCES `bloc` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `bloc_category_en`
--
ALTER TABLE `bloc_category_en`
  ADD CONSTRAINT `FK_47AFCD982D214E40` FOREIGN KEY (`categorytranslation_id`) REFERENCES `category_translation` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_47AFCD985582E9C0` FOREIGN KEY (`bloc_id`) REFERENCES `bloc` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `bloc_category_fr`
--
ALTER TABLE `bloc_category_fr`
  ADD CONSTRAINT `FK_7883C2142D214E40` FOREIGN KEY (`categorytranslation_id`) REFERENCES `category_translation` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_7883C2145582E9C0` FOREIGN KEY (`bloc_id`) REFERENCES `bloc` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `bloc_content_de`
--
ALTER TABLE `bloc_content_de`
  ADD CONSTRAINT `FK_A3C9F4A068204D1A` FOREIGN KEY (`contenttranslation_id`) REFERENCES `contenttranslation` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_A3C9F4A05582E9C0` FOREIGN KEY (`bloc_id`) REFERENCES `bloc` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `bloc_content_en`
--
ALTER TABLE `bloc_content_en`
  ADD CONSTRAINT `FK_2D001C6968204D1A` FOREIGN KEY (`contenttranslation_id`) REFERENCES `contenttranslation` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_2D001C695582E9C0` FOREIGN KEY (`bloc_id`) REFERENCES `bloc` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `bloc_content_fr`
--
ALTER TABLE `bloc_content_fr`
  ADD CONSTRAINT `FK_122C13E568204D1A` FOREIGN KEY (`contenttranslation_id`) REFERENCES `contenttranslation` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_122C13E55582E9C0` FOREIGN KEY (`bloc_id`) REFERENCES `bloc` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `categories_ext`
--
ALTER TABLE `categories_ext`
  ADD CONSTRAINT `FK_3FA0CAAA727ACA70` FOREIGN KEY (`parent_id`) REFERENCES `categories_ext` (`id`) ON DELETE SET NULL;

--
-- Contraintes pour la table `category_country`
--
ALTER TABLE `category_country`
  ADD CONSTRAINT `FK_94AB89182D214E40` FOREIGN KEY (`categorytranslation_id`) REFERENCES `category_translation` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_94AB8918F92F3E70` FOREIGN KEY (`country_id`) REFERENCES `country` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `category_translation`
--
ALTER TABLE `category_translation`
  ADD CONSTRAINT `FK_3F20704126F525E` FOREIGN KEY (`item_id`) REFERENCES `categories_ext` (`id`),
  ADD CONSTRAINT `FK_3F2070431098462` FOREIGN KEY (`lang`) REFERENCES `language` (`id`);

--
-- Contraintes pour la table `conseiller`
--
ALTER TABLE `conseiller`
  ADD CONSTRAINT `FK_18C69F97D725330D` FOREIGN KEY (`agence_id`) REFERENCES `agence` (`id`);

--
-- Contraintes pour la table `content`
--
ALTER TABLE `content`
  ADD CONSTRAINT `FK_FEC530A94C2F0703` FOREIGN KEY (`id_content_taxonomy`) REFERENCES `contenttaxonomy` (`id`);

--
-- Contraintes pour la table `contenttranslation`
--
ALTER TABLE `contenttranslation`
  ADD CONSTRAINT `FK_4E1B03E5126F525E` FOREIGN KEY (`item_id`) REFERENCES `content` (`id`),
  ADD CONSTRAINT `FK_4E1B03E531098462` FOREIGN KEY (`lang`) REFERENCES `language` (`id`);

--
-- Contraintes pour la table `content_category`
--
ALTER TABLE `content_category`
  ADD CONSTRAINT `FK_54FBF32E2D214E40` FOREIGN KEY (`categorytranslation_id`) REFERENCES `category_translation` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_54FBF32E68204D1A` FOREIGN KEY (`contenttranslation_id`) REFERENCES `contenttranslation` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `content_country`
--
ALTER TABLE `content_country`
  ADD CONSTRAINT `FK_8C7B10D568204D1A` FOREIGN KEY (`contenttranslation_id`) REFERENCES `contenttranslation` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_8C7B10D5F92F3E70` FOREIGN KEY (`country_id`) REFERENCES `country` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `fields`
--
ALTER TABLE `fields`
  ADD CONSTRAINT `FK_7EE5E388164C82F6` FOREIGN KEY (`id_field_taxonomy`) REFERENCES `fieldtaxonomy` (`id`);

--
-- Contraintes pour la table `fieldsvalue`
--
ALTER TABLE `fieldsvalue`
  ADD CONSTRAINT `FK_46BE0B82443707B0` FOREIGN KEY (`field_id`) REFERENCES `fields` (`id`),
  ADD CONSTRAINT `FK_46BE0B82F641D1F1` FOREIGN KEY (`content_translation_id`) REFERENCES `contenttranslation` (`id`);

--
-- Contraintes pour la table `fields_content_taxonomy`
--
ALTER TABLE `fields_content_taxonomy`
  ADD CONSTRAINT `FK_8469A872C5439AE` FOREIGN KEY (`fields_id`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_8469A876F25A07C` FOREIGN KEY (`contenttaxonomy_id`) REFERENCES `contenttaxonomy` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `formfields`
--
ALTER TABLE `formfields`
  ADD CONSTRAINT `FK_779AABD7DB055841` FOREIGN KEY (`id_form_field_taxonomy`) REFERENCES `formfieldtaxonomy` (`id`);

--
-- Contraintes pour la table `formfieldsvalue`
--
ALTER TABLE `formfieldsvalue`
  ADD CONSTRAINT `FK_2C32B76E11386F6` FOREIGN KEY (`formfield_id`) REFERENCES `formfields` (`id`),
  ADD CONSTRAINT `FK_2C32B76E5053569B` FOREIGN KEY (`formulaire_id`) REFERENCES `formulaire` (`id`);

--
-- Contraintes pour la table `formulaire`
--
ALTER TABLE `formulaire`
  ADD CONSTRAINT `FK_5BDD01A8F200EC1C` FOREIGN KEY (`id_form_taxonomy`) REFERENCES `formtaxonomy` (`id`);

--
-- Contraintes pour la table `formulairecrm`
--
ALTER TABLE `formulairecrm`
  ADD CONSTRAINT `FK_ADC83951C76985ED` FOREIGN KEY (`currentStatut_id`) REFERENCES `histostatut` (`id`),
  ADD CONSTRAINT `FK_ADC83951F575EFC8` FOREIGN KEY (`currentTypeEmail_id`) REFERENCES `histoemail` (`id`);

--
-- Contraintes pour la table `form_fields_taxonomy`
--
ALTER TABLE `form_fields_taxonomy`
  ADD CONSTRAINT `FK_D3D6C550B3AEF98A` FOREIGN KEY (`formfields_id`) REFERENCES `formfields` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_D3D6C550FFDB5A1A` FOREIGN KEY (`formtaxonomy_id`) REFERENCES `formtaxonomy` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `histoemail`
--
ALTER TABLE `histoemail`
  ADD CONSTRAINT `FK_33904FA0A76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  ADD CONSTRAINT `FK_33904FA0D2D2D17` FOREIGN KEY (`typeEmail_id`) REFERENCES `typeemail` (`id`);

--
-- Contraintes pour la table `histostatut`
--
ALTER TABLE `histostatut`
  ADD CONSTRAINT `FK_640EE4411AC39A0D` FOREIGN KEY (`conseiller_id`) REFERENCES `conseiller` (`id`),
  ADD CONSTRAINT `FK_640EE441234847D` FOREIGN KEY (`caisseRegionale_id`) REFERENCES `caisseregionale` (`id`),
  ADD CONSTRAINT `FK_640EE44123866917` FOREIGN KEY (`statutDemande_id`) REFERENCES `statutdemande` (`id`),
  ADD CONSTRAINT `FK_640EE4412AADBACD` FOREIGN KEY (`langue_id`) REFERENCES `language` (`id`),
  ADD CONSTRAINT `FK_640EE44145BA76BB` FOREIGN KEY (`provenanceDemande_id`) REFERENCES `provenancedemande` (`id`),
  ADD CONSTRAINT `FK_640EE441A76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  ADD CONSTRAINT `FK_640EE441B1572176` FOREIGN KEY (`typeRecommandation_id`) REFERENCES `typerecommandation` (`id`),
  ADD CONSTRAINT `FK_640EE441D725330D` FOREIGN KEY (`agence_id`) REFERENCES `agence` (`id`),
  ADD CONSTRAINT `FK_640EE441DF045DC2` FOREIGN KEY (`agenceCaisseRegionale_id`) REFERENCES `agencecaisseregionale` (`id`);

--
-- Contraintes pour la table `menutranslation_country`
--
ALTER TABLE `menutranslation_country`
  ADD CONSTRAINT `FK_9B98690CF92F3E70` FOREIGN KEY (`country_id`) REFERENCES `country` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_9B98690C95393E9D` FOREIGN KEY (`menutranslation_id`) REFERENCES `menu_translations_ext` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `menu_country_ext`
--
ALTER TABLE `menu_country_ext`
  ADD CONSTRAINT `FK_5207BEDFCCD7E912` FOREIGN KEY (`menu_id`) REFERENCES `menu_ext` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_5207BEDFF92F3E70` FOREIGN KEY (`country_id`) REFERENCES `country` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `menu_ext`
--
ALTER TABLE `menu_ext`
  ADD CONSTRAINT `FK_997258306F6B2CCE` FOREIGN KEY (`id_menu_taxonomy`) REFERENCES `menutaxonomy` (`id`),
  ADD CONSTRAINT `FK_99725830727ACA70` FOREIGN KEY (`parent_id`) REFERENCES `menu_ext` (`id`) ON DELETE SET NULL;

--
-- Contraintes pour la table `menu_translations_ext`
--
ALTER TABLE `menu_translations_ext`
  ADD CONSTRAINT `FK_59941099232D562B` FOREIGN KEY (`object_id`) REFERENCES `menu_ext` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `metasvalue`
--
ALTER TABLE `metasvalue`
  ADD CONSTRAINT `FK_825F2B2039FCA6F9` FOREIGN KEY (`meta_id`) REFERENCES `metas` (`id`),
  ADD CONSTRAINT `FK_825F2B20F641D1F1` FOREIGN KEY (`content_translation_id`) REFERENCES `contenttranslation` (`id`);

--
-- Contraintes pour la table `metasvaluecategory`
--
ALTER TABLE `metasvaluecategory`
  ADD CONSTRAINT `FK_47E4F2139FCA6F9` FOREIGN KEY (`meta_id`) REFERENCES `metas` (`id`),
  ADD CONSTRAINT `FK_47E4F217DBA6818` FOREIGN KEY (`category_translation_id`) REFERENCES `category_translation` (`id`);

--
-- Contraintes pour la table `urls_content`
--
ALTER TABLE `urls_content`
  ADD CONSTRAINT `FK_8C28CEEA84A0A3ED` FOREIGN KEY (`content_id`) REFERENCES `contenttranslation` (`id`);

--
-- Contraintes pour la table `user_group`
--
ALTER TABLE `user_group`
  ADD CONSTRAINT `FK_8F02BF9DA76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_8F02BF9DFE54D947` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
